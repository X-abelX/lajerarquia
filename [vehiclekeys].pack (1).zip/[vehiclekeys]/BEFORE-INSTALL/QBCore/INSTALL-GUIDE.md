##### DEPENDENCYS ##### 
# Dependencies

# These scripts are not mandatory but they are the ones that work by default, if you don't have them you have to modify yours

# lockpick   : https://github.com/Clefas/lockpick
# skillbar   : https://github.com/Utinax/reload-skillbar

# Only if you use hotwire
# baseevents : https://github.com/citizenfx/cfx-server-data

##### STEP 1 #####
# ADD THE ITEMS

## If you have `QS-INVENTORY or QB-INVENTORY`
Go to `qb-core/shared/items.lua` at the end of the file, `COPY and PASTE` the items into the file called `BEFORE-INSTALL\QBCore\STEP-1\qs-inventory.lua`.

You must add the following line in our `qs-inventory/config/metadata.js` or `qb-inventory/html/js/app.js`.
```js
} else if (itemData.name == "vehiclekeys") {
    $(".item-info-title").html("<p>" + itemData.label + "</p>");
    $(".item-info-description").html(
        "<p><strong>Plate: </strong><span>" +
        itemData.info.plate +
        "</span></p><p><strong>Model: </strong><span>" +
        itemData.info.description +
        "</span></p>"
    );
} else if (itemData.name == "plate") {
    $(".item-info-title").html("<p>" + itemData.label + "</p>");
    $(".item-info-description").html(
        "<p><strong>Plate: </strong><span>" +
        itemData.info.plate +
        "</span></p>"
    );
```

## If you have `OX_INVENTORY`
Go to `ox_inventory/data/items.lua` at the end of the file, `COPY and PASTE` the items into the file called `BEFORE-INSTALL\QBCore\STEP-1\ox_inventory.lua`.

## If you have `CORE_INVENTORY`
Go to `core_inventory/config.lua` and `COPY and PASTE` the execute on your sql the file called `BEFORE-INSTALL\QBCore\STEP-1\core_inventory.sql`.
and add this on core_inventory/config.lua on ItemCategories

["vehiclekeys"] = {
    color = "#62a859",
    takeSound = 'take_fabric',
    putSound = 'put_fabric',
},

##### STEP 2 #####
# START RESOURCES
Always start the script after your inventory and after your qb-core, add this in your `server.cfg`

ensure baseevents
ensure lockpick
ensure reload-skillbar
ensure qs-inventory


##### STEP 3 #####
# CONFIGURE THE SCRIPT

Go to `qs-vehiclekeys/config/config.lua`, in line 11 change `esx` to `qb`. It has to look like this : `Config.Framework = "qb" -- 'esx' or 'qb'`

##### STEP 4 #####
# MODIFICATIONS 

Go `qb-inventory/server/main.lua` and give you the plate item with metadata you have to modify your giveitem command.

# Add this before giveitem command
# Line ~ 2369
```lua
function generar_matricula()
	local caracteres = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	local matricula = ""
	
	for i = 1, 8 do
		local aleatorio = math.random(1, #caracteres)
		matricula = matricula .. caracteres:sub(aleatorio, aleatorio)
	end
	
	return matricula
end
```
```lua
elseif itemData["name"] == "plate" then
	info.plate = generar_matricula()
```

Example : `https://media.discordapp.net/attachments/1042987814616301668/1117942619864039444/spaces2F1NOrGbEUnhSu3KdXH50k2Fuploads2FRuTZQKqLVqEvh3xv3Kxi2FScreenshot202023-05-2020202429.png?width=1047&height=701`

Go to `qb-core/server/events.lua` line 201 and remove this code:
Image `https://media.discordapp.net/attachments/1042987814616301668/1117943319922753596/image.png?width=627&height=701`

##### STEP 5 #####
# FINAL STEP 

To make modifications to your scripts you need to read the documentation compulsorily.
`https://docs.quasar-store.com/qbcore/vehiclekeys/installations#8.-what-changes-should-we-make-to-our-other-assets`
