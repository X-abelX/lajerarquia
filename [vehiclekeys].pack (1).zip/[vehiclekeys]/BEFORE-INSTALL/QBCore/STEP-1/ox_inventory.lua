-- * qs-vehiclekeys
["vehiclekeys"] = {
	label = "Keys",
	weight = 1,
	stack = false,
	close = false,
	consume = 0,
	client = {
		export = 'qs-vehiclekeys.useKey',
	},
},

['plate'] = {
	label = 'Plate',
	weight = 100,
	stack = true,
	close = false,
	consume = 0,
	client = {
		export = 'qs-vehiclekeys.usePlate',
	},
},

['carlockpick'] = {
	label = 'Car Lockpick',
	weight = 100,
	stack = true,
	close = false,
	description = "A Lockpick.",
	consume = 1,
	client = {
	export = 'qs-vehiclekeys.useLockpick',
	},
},

['caradvancedlockpick'] = {
	label = 'Advanced Lockpick',
	weight = 100,
	stack = true,
	close = false,
	description = "If you lose your keys a lot this is very useful."
},

['screwdriver'] = {
	label = 'Screwdriver',
	weight = 100,
	stack = true,
	close = false,
	description = "Tool used to change plate."
},

['rentalpaper'] = {
	label = 'Rental Paper',
	weight = 0,
	stack = true,
	close = true,
	description = 'Vehicle rental paper'
},

