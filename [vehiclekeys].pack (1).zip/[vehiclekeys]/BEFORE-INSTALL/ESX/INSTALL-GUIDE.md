##### DEPENDENCYS ##### 
# Dependencies

# These scripts are not mandatory but they are the ones that work by default, if you don't have them you have to modify yours

# lockpick   : https://github.com/Clefas/lockpick
# skillbar   : https://github.com/Utinax/reload-skillbar

# Only if you use hotwire
# baseevents : https://github.com/citizenfx/cfx-server-data

##### STEP 1 #####
# ADD THE ITEMS

## If you have `QS-INVENTORY`
Go to `qs-inventory/shared/items.lua` at the end of the file, `COPY and PASTE` the items into the file called `BEFORE-INSTALL\ESX\STEP-1\qs-inventory.lua`.

You must add the following line in our qs-inventory/config/metadata.js.
```js
} else if (itemData.name == "vehiclekeys") {
    $(".item-info-title").html("<p>" + itemData.label + "</p>");
    $(".item-info-description").html(
        "<p><strong>Plate: </strong><span>" +
        itemData.info.plate +
        "</span></p><p><strong>Model: </strong><span>" +
        itemData.info.description +
        "</span></p>"
    );
} else if (itemData.name == "plate") {
    $(".item-info-title").html("<p>" + itemData.label + "</p>");
    $(".item-info-description").html(
        "<p><strong>Plate: </strong><span>" +
        itemData.info.plate +
        "</span></p>"
    );
```

## If you have `OX_INVENTORY`
Go to `ox_inventory/data/items.lua` at the end of the file, `COPY and PASTE` the items into the file called `BEFORE-INSTALL\ESX\STEP-1\ox_inventory.lua`.

## If you have `CORE_INVENTORY`
Go to `core_inventory/config.lua` and `COPY and PASTE` the execute on your sql the file called `BEFORE-INSTALL\ESX\STEP-1\core_inventory.sql`.
and add this on core_inventory/config.lua on ItemCategories

["vehiclekeys"] = {
    color = "#62a859",
    takeSound = 'take_fabric',
    putSound = 'put_fabric',
},

##### STEP 2 #####
# START RESOURCES
Always start the script after your inventory and after your es_extended, add this in your `server.cfg`

ensure baseevents
ensure lockpick
ensure reload-skillbar
ensure qs-inventory


##### STEP 3 #####
# CONFIGURE THE SCRIPT

Go to `qs-vehiclekeys/config/config.lua`, in line 11 change `qb` to `esx`. It has to look like this : `Config.Framework = "esx" -- 'esx' or 'qb'`

##### STEP 4 #####
# FINAL STEP 

To make modifications to your scripts you need to read the documentation compulsorily.
`https://docs.quasar-store.com/esx/vehiclekeys/installations#1.-changes-to-add-keys`     
