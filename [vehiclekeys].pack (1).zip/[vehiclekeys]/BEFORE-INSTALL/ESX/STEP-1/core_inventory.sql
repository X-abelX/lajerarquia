INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`, `x`, `y`, `category`, `componentTint`, `componentHash`, `backpackModel`, `backgroundTexture`, `description`) VALUES
('vehiclekeys', 'Vehicle Keys', '1', '0', '1', '1', '1', 'vehiclekeys', NULL, NULL, NULL, NULL, 'A small and sweet casting.'),
('plate', 'Plate', '1', '0', '1', '1', '1', 'vehiclekeys', NULL, NULL, NULL, NULL, 'A plate.'),
('carlockpick', 'Car LockPick', '1', '0', '1', '1', '1', 'vehiclekeys', NULL, NULL, NULL, NULL, 'A Lockpick.'),
('caradvancedlockpick', 'Car Advanced Lockpick', '1', '0', '1', '2', '2', 'vehiclekeys', NULL, NULL, NULL, NULL, 'If you lose your keys a lot, this is very useful.'),
('screwdriver', 'Screwdriver', '1', '0', '1', '2', '2', 'vehiclekeys', NULL, NULL, NULL, NULL, 'Tool used to change the plate.'),
('rentalpaper', 'Rental Paper', '0', '0', '1', '1', '1', 'vehiclekeys', NULL, NULL, NULL, NULL, 'Vehicle rental paper');
