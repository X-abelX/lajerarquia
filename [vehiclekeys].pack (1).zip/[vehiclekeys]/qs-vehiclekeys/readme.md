# qs-vehiclekeys Changelog

## Version 3.4.1
- **Fixed:**
  - Money not being removed when buying a plate.
  - Default config is now menu instead of shop.
  - `ox_target` function not being translatable.
  - Locales; all missing strings are now added.

## Version 3.4.2
- **Fixed:**
  - `textui` showing when the target was active.
  - `ox_target` function being translated wrongly.
- **Improved:**
  - Lockpick now works on spawned cars from GTA V.
  - Moved `useLockpick` to a function & added exports for `ox_inventory` compatibility.
- **Cleaned up:**
  - fxmanifest.
- **Added:**
  - Locales for the new screwdriver.
  - Possibility of buying a screwdriver (needed for installing the plated) in the menu type.
- **Updated:**
  - All types of menus.

## Version 3.4.3
- **Fixed:**
  - Menu types.

## Version 3.4.4
- **Fixed:**
  - `ox_inventory`.
- **Added:**
  - `qb-target` support.

## Version 3.4.5
- **Fixed:**
  - Lockpick functions.

## Version 3.4.6
- **Fixed:**
  - Sounds not being heard for players around you.
  - Some prints on the debug.
- **Improved:**
  - Parsing on some parts.

## Version 3.4.7
- **Fixed:**
  - `" "` character.
  - Some sounds being louder than others.

## Version 3.4.8
- **Fixed:**
  - Dispatch functions.

## Version 3.4.9
- **Fixed:**
  - Money not being removed when buying a screwdriver in the menu functions.

## Version 3.5.0
- **Fixed:**
  - qbcore menu & qbcore target.

## Version 3.5.1
- **Added:**
  - Ability to disable/enable notifications when opening and closing vehicles.

## Version 3.5.2
- **Restored:**
  - Possibility to modify the animations and props.
- **Fixed:**
  - Some checks of the car state for the lockpick.
- **Added:**
  - New security check to prevent mistakes on the framework account Config. (Warning will now be added on server-side).

## Version 3.5.3
- **Enhanced:**
  - Debug functions for the locking of car doors.

## Version 3.5.4
- **Fixed:**
  - Quasar dispatch functions.

## Version 3.5.5
- **Improved:**
  - Lockpick functions. (You will not be able to lockpick from the inside of a car anymore.)
- **Added:**
  - Chinese locales.

## Version 3.5.6
- **Improved:**
  - Door-locking function.
- **Cleaned up:**
  - Debug.
- **NEW:**
  - Minigame configured by default: `t3_lockpick`.

## Version 3.5.7
- **Fixed:**
  - `core_inventory` SQL.
- **Fixed:**
  - Entering vehicle function.

## Version 3.5.8
- **Fixed:**
  - Stealing vehicles from peds with melee weapons.

## Version 3.5.9
- **Fixed:**
  - qbcore functions to change the plate.

## Version 3.6.0
- **Added:**
  - Config for selecting which weapons you can steal the vehicles with.

## Version 3.6.1
- **Improved and cleaned:**
  - Door logic functions.

## Version 3.6.2
- **Improved and cleaned:**
  - Plate and target functions.

## Version 3.6.3
- **Added:**
  - New security feature to prevent players from using a plate on a locked car.
- **Improved:**
  - Logging with additional debug prints in critical sections of the code.
- **Fixed:**
  - Issues with the `processEntering` function not being called and `info.event` not set correctly to 'Entering'.
  - Duplicate notification while lockpicking a vehicle.
- **Ensured:**
  - `initKeys` function is correctly called to handle hotwiring initiation.
- **Added:**
  - Comments to the code for enhanced readability.

## Version 3.6.4
- **Fixed:**
  - `Config.AllVehiclesLocked` preventing the use of lockpick functions.

## [Version 3.6.5](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.6.5)
- **Fixed:**
  - Various bugs related to the `Config.AllVehiclesLocked` functions.
- **Improved:**
  - Notification handling during lockpicking to avoid duplicates.

## [Version 3.6.6](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.6.6)
- **Changed:**
  - Renamed `Config.AllVehiclesLocked` function to `Config.NpcVehiclesLocked` for improved clarity.
- **Added:**
  - New check to prevent giving keys to a player if they already possess an item for the same vehicle.
- **Fixed:**
  - Various bugs related to the `Config.NpcVehiclesLocked` functions.

## [Version 3.6.7](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.6.7)
- **Improved:**
  - Plate usage functionality and checks.

## [Version 3.6.8](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.6.8)
- **Improved:**
  - Debug functions are now colored.
  - Debug functions are now more useful.

## [Version 3.6.9](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.6.9)
- **Added:**
  - Codem inventory support.

 ## [Version 3.7.0](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.7.0)
- **Added:**
  - Version checker.

 ## [Version 3.7.1](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.7.1)
- **Improved:**
  - `NpcVehiclesLocked` functions.

 ## [Version 3.7.2](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.7.2)
- **Added:**
  - New exports `DoorLogic` to lock / unlock a vehicle.
- **Improved:**
  - `DoorLogic` function.
- **Updated:**
  - The updated debug function will provide clearer explanations regarding the current status of the doors.

### DoorLogic Export:

```lua
DoorLogic(vehicle, skipAnimation, forcedDoorStatus)
```

- **Parameters:**
  - `vehicle`: The vehicle entity for which the door logic will be applied.
  - `skipAnimation` (optional, default is `false`): If `true`, skips the lock/unlock animation.
  - `forcedDoorStatus` (optional): If provided, forces the door status to the specified value.

- **Usage Example:**
  ```lua
  exports["qs-vehiclekeys"]:DoorLogic(vehicle, true, 1)
  ```

- **Notes:**
  - The `skipAnimation` parameter, when set to `true`, skips the lock/unlock animation (default is `false`).
  - The `forcedDoorStatus` parameter, when provided, forces the door status to the specified value.

  **Door Status Values:**
  - **0: None**
    - The doors are in an undefined or neutral state.
  - **1: Unlocked**
    - Indicates that the doors are currently unlocked.
  - **2: Locked**
    - Indicates that the doors are securely locked.

## [Version 3.7.3](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.7.3)
- **Improved:**
  - Optimized the `initKeys` function, addressing performance concerns.
  - Modified the `Draw3DText` function to handle the replacement of `DrawText3D` more effectively, ensuring proper text visibility control.
  - Enhanced code logic to improve the closure of text UI during specific conditions.
  - Streamlined code structure for better readability.
- **Added:**
  - New custom file `Draw3DText.lua` for prompting the hotwire.

## [Version 3.7.4](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.7.4)
- **Added:**
  - New exports `AddRentalPapers` and `RemoveRentalPapers` to add and remove rental papers from a player's inventory.

### AddRentalPapers Export:

```lua
AddRentalPapers(plate, model)
```

- **Parameters:**
  - `plate`: The vehicle plate associated with the rental papers.
  - `model`: The vehicle model associated with the rental papers.

- **Usage Example:**
  ```lua
  exports["qs-vehiclekeys"]:AddRentalPapers("ABC123", "adder")
  ```

- **Notes:**
  - The function adds rental papers to the player's inventory based on the provided plate and model.

### RemoveRentalPapers Export:

```lua
RemoveRentalPapers(plate, model)
```

- **Parameters:**
  - `plate`: The vehicle plate associated with the rental papers.
  - `model`: The vehicle model associated with the rental papers.

- **Usage Example:**
  ```lua
  exports["qs-vehiclekeys"]:RemoveRentalPapers("ABC123", "adder")
  ```

- **Notes:**
  - The function removes rental papers from the player's inventory based on the provided plate and model.
  - These exports behave similarly to `GiveKeys` and `RemoveKeys` exports.
  
  **Rental Papers Item Configuration:**
  - Configure the rental papers item name in your script's configuration file (e.g., `Config.RentalPaperItem`).

  **Inventory Script Compatibility:**
  - These exports are compatible with multiple inventory scripts, supporting different metadata structures.

### Rental Papers metadata.js

```javascript
} else if (itemData.name == "rentalpaper") {
  $(".item-info-title").html("<p>Rental Paper</p>");
  $(".item-info-description").html(
      "<p><strong>Owner: </strong><span>" +
      itemData.info.owner +
      "</span></p><p><strong>Plate: </strong><span>" +
      itemData.info.plate +
      "</span></p><p><strong>Vehicle: </strong><span>" +
      itemData.info.vehicle +
      "</span></p>"
  );
```
## [Version 3.7.5](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.7.5)
- **Improved:**
  - Codem inventory support.

## [Version 3.7.6](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.7.6)

- **Added:**
  - New export `GetDoorState` to retrieve the current door state of a specified vehicle.

- **Fixed:**
  - Addressed issues in `TextUI/drawtext3d.lua`, `TextUI/HelpNotification.lua`, and `TextUI/HelpNotification.lua`.
  - Fixed an inconsistency with `Config.PersistantCheck` and `Config.PersistantCheckTime`.

### GetDoorState Export:

```lua
GetDoorState(vehicle)
```

- **Parameters:**
  - `vehicle`: A reference to the vehicle entity.

- **Returns:**
  - `number`: An integer representing the door state of the vehicle. The possible values are as follows:
    - `0`: None
    - `1`: Unlocked
    - `2`: Locked
    - `3`: LockedForPlayer
    - `4`: StickPlayerInside
    - `7`: CanBeBrokenInto
    - `8`: CanBeBrokenIntoPersist
    - `10`: CannotBeTriedToEnter
    - Other values: Unknown Status

- **Usage Example:**
  ```lua
  local vehicle = GetVehiclePedIsIn(PlayerId(), false)
  local doorState = exports["qs-vehiclekeys"]:GetDoorState(vehicle)
  print("Door State: " .. doorState)
  ```

### Fixed:

- **TextUI/drawtext3d.lua:**
  - Resolved issues related to rendering 3D text on the screen.

- **TextUI/HelpNotification.lua:**
  - Addressed problems with the Help Notification system.

- **TextUI/HelpNotification.lua:**
  - Corrected inconsistencies in file names and functionalities.

- **Config.PersistantCheck:**
  - Fixed an issue with `Config.PersistantCheck` and `Config.PersistantCheckTime`:
    - `Config.PersistantCheck` now works as intended.
    - `Config.PersistantCheckTime` intervals adjusted for better performance.

### Configuration:

```lua
Config.PersistantCheck = true -- If true, the script will always check if the player has keys for the vehicle the player is in.
Config.PersistantCheckTime = 1250 -- Time in MS at which intervals the check should be executed !!! The lower the number, the more will the performance be impacted !!!
```

### Notes

- Ensure that the `GetDoorState` export is available in your environment.
- Make sure to pass a valid vehicle reference when calling the `GetDoorState` function.
- The door state values correspond to the possible door lock statuses in GTA V.

## [Version 3.7.7](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.7.7)

- **Added:**
  - New functionality: Introducing `TextUI` support.
- **Improved:**
  - Enhanced the `TextShow` function for a more customizable user experience.
  - Improved support for custom icons and text UI design options.
- **Fixed:**
  - Addressed an issue related to the `TextClose` function.
  - Resolved compatibility issues with certain configurations.

## [Version 3.7.8](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.7.8)

- **Modified:**
  - New parameters for the `DoorLogic` exports to ensure better script usage.

- **Improved:**
  - `DoorLogic` function.

- **Updated:**
  - The updated debug function will provide clearer explanations regarding the current status of the doors.

### DoorLogic Export:

```lua
DoorLogic(vehicle, skipAnimation, forcedDoorStatus, skipNotification, skipSound, skipFlickerLights)
```

- **Parameters:**
  - `vehicle`: The vehicle entity for which the door logic will be applied.
  - `skipAnimation` (optional, default is `false`): If `true`, skips the lock/unlock animation.
  - `forcedDoorStatus` (optional): If provided, forces the door status to the specified value.
  - `skipNotification` (optional, default is `false`): If `true`, skips displaying notifications.
  - `skipSound` (optional, default is `false`): If `true`, skips playing default vehicle door sounds.
  - `skipFlickerLights` (optional, default is `false`): If `true`, skips flickering lights.

- **Usage Example:**
  ```lua
  exports["qs-vehiclekeys"]:DoorLogic(vehicle, true, 1, false, false, false)
  ```

- **Notes:**
  - The `skipAnimation` parameter, when set to `true`, skips the lock/unlock animation (default is `false`).
  - The `forcedDoorStatus` parameter, when provided, forces the door status to the specified value.
  - The `skipNotification` parameter, when set to `true`, skips displaying notifications (default is `false`).
  - The `skipSound` parameter, when set to `true`, skips playing default vehicle door sounds (default is `false`).
  - The `skipFlickerLights` parameter, when set to `true`, skips flickering lights (default is `false`).

  **Door Status Values:**
  - **0: None**
    - The doors are in an undefined or neutral state.
  - **1: Unlocked**
    - Indicates that the doors are currently unlocked.
  - **2: Locked**
    - Indicates that the doors are securely locked.

## [Version 3.7.9](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.7.9)
- **Fixed:**
  - Issue with `GetPedsInVehicle` function, resolving nil values and ensuring accurate ped information retrieval.

## [Version 3.8.0](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.8.0)
- **DUMMY VERSION:**
  - Done in order to catch up with the version checker.

## [Version 3.8.1](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.8.1)
- **Updated:**
  - Updated the following menus ox_lib, qb, esx_default_menu, if you are using nh menu or esx_context please open a ticket to make yourselves known.
  - You will now be able to copy the keys inside your inventory
 
 - **Improved:**
  - Security functions and debug when opening the copy keys menu on `qbcore`.   
  
- **Added:**
  - New parameter for the givekeys exports `bypassKeyCheck`.
  
```lua
-- GiveKeys
-- Export to give the keys of a specified vehicle.
-- plate: Vehicle plate
-- model: Vehicle model
-- bypassKeyCheck (optional, default is false): If true, bypasses the key validation check before giving the keys.
exports['qs-vehiclekeys']:GiveKeys(plate, model, bypassKeyCheck)
```

**Parameters:**
- `plate`: The plate of the vehicle for which keys will be given.
- `model`: The model of the vehicle for which keys will be given.
- `bypassKeyCheck` (optional, default is `false`): If set to `true`, the export bypasses the key validation check before giving the keys.

**Usage Example:**
```lua
exports['qs-vehiclekeys']:GiveKeys('ABC123', 'adder', true)
```

**Notes:**
- The `bypassKeyCheck` parameter, when set to `true`, bypasses the key validation check.

## [Version 3.8.2](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.8.2)
- **Improved:**
  - Further enhancements to Codem inventory support.
- **Fixed:**
  - Added missing config for rental papers.

## [Version 3.8.3](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.8.3)
- **Fixed:**
  - Corrected naming of the `AddRentalPapers` exports.

## [Version 3.8.4](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.8.4)
- **Fixed:**
  - Corrected function names in debug logs.
- **Improved:**
  - Admin command for `givekeys` now bypasses checks to give the key even if the player already has it.

## [Version 3.8.5](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.8.5)
- **Fixed:**
  - TextUI duration issue within vehicles.

## [Version 3.8.6](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.8.6)
- **Fixed:**
  - DoorLogic exports.

## [Version 3.8.7](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.8.7)
- **Added:**
  - Update plate functions moved to open-source.

## [Version 3.8.8](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.8.8)
- **Improved:**
  - Commands functions will still work when `Config.HotKeys` is `false`.

## [Version 3.8.9](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.8.9)
- **Improved:**
  - Addded the `TextClose` function into the hotwire file.

## [Version 3.9.0](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.9.0)
- **Improved:**
  - Addded checks for `radial` functions, usekey will only show when you're nearby a vehicle.

## [Version 3.9.1](https://github.com/quasar-store-organizations/qs-vehiclekeys/releases/tag/3.9.1)
- **Fixed:**
  - `DoorLogic` exports.
  - `TextUI` functions.
