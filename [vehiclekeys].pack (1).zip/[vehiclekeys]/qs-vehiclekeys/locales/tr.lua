Locales["tr"] = {
    ["VEHICLEKEYS_MENU_TITLE"] = "Anahtar Kopyala",
    ["VEHICLEKEYS_MENU_MODEL"] = "Model:",
    ["VEHICLEKEYS_MENU_PLATE"] = "Plaka:",

    ["VEHICLEKEYS_DRAWTEXT_COPYKEYS"] = "[E] - Anahtar Kopyala",
    ["VEHICLEKEYS_DRAWTEXT_CHARGE"] = "Şarj:",

    ["VEHICLEKEYS_NOTIFICATION_NO_VEHICLES"] = "Yakınlarda araç yok",
    ["VEHICLEKEYS_NOTIFICATION_NO_KEYS"] = "Bu aracın anahtarlarına sahip değilsiniz",
    ["VEHICLEKEYS_NOTIFICATION_CHANGE_PLATE"] = "Plakanızı değiştirdiniz:",
    ["VEHICLEKEYS_NOTIFICATION_NO_PLATES"] = "Bu aracın anahtarlarına sahip değilsiniz",
    ["VEHICLEKEYS_NOTIFICATION_LOCK"] = "Araç kilidini taktınız",
    ["VEHICLEKEYS_NOTIFICATION_UNLOCK"] = "Araç kilidini açtınız",
    ["VEHICLEKEYS_NOTIFICATION_NO_MONEY"] = "Yeterli paranız yok",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_SUCCESS"] = "Kilidi başarıyla açtınız",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_BROKEN"] = "Kırık açma aletiniz var",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_FAIL"] = "Araç kilidini açamadınız",
    ["VEHICLEKEYS_NOTIFICATION_TITLE"] = "Araç Hırsızlığı",
    ["VEHICLEKEYS_NOTIFICATION_POLICE_DISPATCH"] = "Bir alarm çaldım:",
    ["VEHICLEKEYS_NOTIFICATION_ALARM"] = "Araç alarmı çalmaya başladı",
    ["VEHICLEKEYS_NOTIFICATION_NO_POLICES"] = "Şehirde yeterince polis yok",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NPC_KEYS"] = "Sivil size aracının anahtarlarını verdi",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_VEHICLE"] = "Telefonunuzu şarj etmek için bir araçta olmalısınız",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_KEYS"] = "Bu aracın anahtarlarına sahip değilsiniz",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_BATTERY_FULL"] = "Batarya zaten %100 dolu",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_CHARGED"] = "Telefonunuz şurada şarj edildi:",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_PHONE"] = "Şarj etmek için bir akıllı telefonunuz yok",

    ["VEHICLEKEYS_HOTWIRE_STEAL"] = "Anahtarları Çalmak",
    ["VEHICLEKEYS_HOTWIRE_TAKING_KEYS"] = "Anahtarları Almak",
    ["VEHICLEKEYS_HOTWIRE"] = "Çalmak için H tuşuna basın",

    ["VEHICLEKEYS_CHANGING_PLATE"] = 'Plaka değişikliği',
    ["VEHICLEKEYS_MENU_TITLE_PLATE"] = 'Plaka Mağazası',
    ["VEHICLEKEYS_MENU_BUY_PLATE"] = 'Bir plaka satın alın',
    ["VEHICLEKEYS_MENU_BUY_PLATE_DESCRIPTION"] = 'Şunun için bir plaka satın alın: $',
    ["VEHICLEKEYS_MENU_BUY_CHANGEPLATE_DESCRIPTION"] = 'Bir tornavida satın alın: $',
    ["VEHICLEKEYS_MENU_NO_CHANGER_ITEM"] = 'Alet yok',
    ["VEHICLEKEYS_PLATE_LOCKED"] = 'Araç kilitli!',

    ["VEHICLEKEYS_LOCKPICK_WHITELIST"] = 'Bu arabanın kilidi açılamaz',

    ["ADMINCOMMAND_NO_VEHICLE"] = "Bir araçta değilsiniz",
    ["ADMINCOMMAND_GIVED_VEHICLE"] = "Araç anahtarlarını başarıyla verdiniz",
    ["ADMINCOMMAND_PLAYER"] = "Oyuncu",
    ["ADMINCOMMAND_HELP"] = "Araç Anahtarları Ver",
    ["ADMINCOMMAND_COMMAND"] = "anahtarver",
    ["ADMINCOMMAND_RANGE"] = "admin",
    ["ADMINCOMMAND_NO_PLAYER"] = "Geçersiz kimlik",

    ["VEHICLEKEYS_RADIAL_VEHICLE_LABEL"] = "Araç",
    ["VEHICLEKEYS_RADIAL_VEHICLEKEYS_LABEL"] = "Anahtarlar",
    ["VEHICLEKEYS_RADIAL_VEHICLESEATBELT_LABEL"] = "Emniyet Kemeri",
    ["VEHICLEKEYS_RADIAL_VEHICLECHAIRS_LABEL"] = "Koltuklar",
    ["VEHICLEKEYS_RADIAL_VEHICLEWINDOWS_LABEL"] = "Pencereler",
    ["VEHICLEKEYS_RADIAL_VEHICLEDOORS_LABEL"] = "Kapılar",
    ["VEHICLEKEYS_RADIAL_VEHICLEENGINE_LABEL"] = "Motor",

    ["VEHICLEKEYS_RADIAL_REARLEFT_LABEL"] = "Sol arka",
    ["VEHICLEKEYS_RADIAL_REARRIGHT_LABEL"] = "Arka sağ",
    ["VEHICLEKEYS_RADIAL_HOOD_LABEL"] = "Kaput",
    ["VEHICLEKEYS_RADIAL_TRUNK_LABEL"] = "Bagaj",
    ["VEHICLEKEYS_RADIAL_DRIVER_LABEL"] = "Sürücü",
    ["VEHICLEKEYS_RADIAL_PASSENGER_LABEL"] = "Yolcu",
    
    ["VEHICLEKEYS_COMMAND_ENGINE"] = 'Aracın kilidini aç/kilitle',
    ["VEHICLEKEYS_COMMAND_USEKEY"] = 'Motor kontrolü',

    -- Hedefleme ve Alışveriş çevirileri

    ["VEHICLEKEYS_PLATE_SHOP_LABEL"] = 'Plaka Mağazası',
    ["VEHICLEKEYS_PLATE_SHOP_NAME"] = 'Plaka Mağazası',

    ["VEHICLEKEYS_OPEN_PLATE"] = 'Mağazayı aç',
    ["VEHICLEKEYS_OPEN_PLATE_TARGET_ICON"] = 'fas-pano',

    ["VEHICLEKEYS_COPY_KEYS"] = 'Anahtarı kopyala',
    ["VEHICLEKEYS_COPY_KEYS_TARGET_ICON"] = 'fas fa-kopyası',

    ["VEHICLEKEYS_OPEN_CLOSE_TARGET"] = 'Aracı aç / kapat',
    ["VEHICLEKEYS_OPEN_CLOSE_TARGET_ICON"] = 'fas fa-key',
}
