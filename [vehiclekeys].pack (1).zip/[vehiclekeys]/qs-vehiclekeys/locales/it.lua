Locales["it"] = {
    ["VEHICLEKEYS_MENU_TITLE"] = "Copia Chiave",
    ["VEHICLEKEYS_MENU_MODEL"] = "Modello:",
    ["VEHICLEKEYS_MENU_PLATE"] = "Targa:",

    ["VEHICLEKEYS_DRAWTEXT_COPYKEYS"] = "[E] - Copia Chiave",
    ["VEHICLEKEYS_DRAWTEXT_PLATE"] = "[E] - Compra un piatto",
    
    ["VEHICLEKEYS_DRAWTEXT_CHARGE"] = "Carica:",

    ["VEHICLEKEYS_NOTIFICATION_NO_VEHICLES"] = "Nessun veicolo nelle vicinanze",
    ["VEHICLEKEYS_NOTIFICATION_NO_KEYS"] = "Non hai le chiavi per quel veicolo",
    ["VEHICLEKEYS_NOTIFICATION_CHANGE_PLATE"] = "Hai cambiato la tua targa in:",
    ["VEHICLEKEYS_NOTIFICATION_NO_PLATES"] = "Non hai le chiavi per questo veicolo",
    ["VEHICLEKEYS_NOTIFICATION_LOCK"] = "Hai bloccato il veicolo",
    ["VEHICLEKEYS_NOTIFICATION_UNLOCK"] = "Hai sbloccato il veicolo",
    ["VEHICLEKEYS_NOTIFICATION_NO_MONEY"] = "Non hai abbastanza soldi",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_SUCCESS"] = "Hai aperto con successo la serratura",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_BROKEN"] = "La tua grimaldello è rotta",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_FAIL"] = "Non sei riuscito a scassinare il veicolo",
    ["VEHICLEKEYS_NOTIFICATION_TITLE"] = "Furto di Veicoli",
    ["VEHICLEKEYS_NOTIFICATION_POLICE_DISPATCH"] = "Ho fatto scattare un allarme su:",
    ["VEHICLEKEYS_NOTIFICATION_ALARM"] = "L'allarme del veicolo ha iniziato a suonare",
    ["VEHICLEKEYS_NOTIFICATION_NO_POLICES"] = "Non ci sono abbastanza agenti di polizia in città",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NPC_KEYS"] = "Il civile ti ha dato le chiavi del suo veicolo",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_VEHICLE"] = "Devi essere in un veicolo per caricare il tuo Smartphone",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_KEYS"] = "Non hai le chiavi per questo veicolo",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_BATTERY_FULL"] = "La batteria è già al 100%",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_CHARGED"] = "Il tuo telefono è stato caricato a:",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_PHONE"] = "Non hai uno Smartphone da caricare",

    ["VEHICLEKEYS_HOTWIRE_STEAL"] = "Rubare le chiavi",
    ["VEHICLEKEYS_HOTWIRE_TAKING_KEYS"] = "Prendere le chiavi",
    ["VEHICLEKEYS_HOTWIRE"] = "Premi H per collegare a caldo",

    ["VEHICLEKEYS_CHANGING_PLATE"] = 'Cambio targa',
    ["VEHICLEKEYS_MENU_TITLE_PLATE"] = 'Negozio di piatti',
    ["VEHICLEKEYS_MENU_BUY_PLATE"] = 'Compra un piatto',
    ["VEHICLEKEYS_MENU_BUY_PLATE_DESCRIPTION"] = 'Compra una targa per: $',
    ["VEHICLEKEYS_MENU_BUY_CHANGEPLATE_DESCRIPTION"] = 'Compra un cacciavite per: $',
    ["VEHICLEKEYS_MENU_NO_CHANGER_ITEM"] = 'Nessuno strumento',
    ["VEHICLEKEYS_PLATE_LOCKED"] = 'Il veicolo è bloccato!',

    ["VEHICLEKEYS_LOCKPICK_WHITELIST"] = 'La serratura di questa macchina non può essere aperta',

    ["ADMINCOMMAND_NO_VEHICLE"] = "Non sei in un veicolo",
    ["ADMINCOMMAND_GIVED_VEHICLE"] = "Hai consegnato le chiavi dell'auto correttamente",
    ["ADMINCOMMAND_PLAYER"] = "Giocatore",
    ["ADMINCOMMAND_HELP"] = "Dai Chiavi del Veicolo",
    ["ADMINCOMMAND_COMMAND"] = "daichiavi",
    ["ADMINCOMMAND_RANGE"] = "admin",
    ["ADMINCOMMAND_NO_PLAYER"] = "ID errato",

    ["VEHICLEKEYS_RADIAL_VEHICLE_LABEL"] = "Veicolo",
    ["VEHICLEKEYS_RADIAL_VEHICLEKEYS_LABEL"] = "Chiavi",
    ["VEHICLEKEYS_RADIAL_VEHICLESEATBELT_LABEL"] = "Cintura",
    ["VEHICLEKEYS_RADIAL_VEHICLECHAIRS_LABEL"] = "Sedili",
    ["VEHICLEKEYS_RADIAL_VEHICLEWINDOWS_LABEL"] = "Finestre",
    ["VEHICLEKEYS_RADIAL_VEHICLEDOORS_LABEL"] = "Porte",
    ["VEHICLEKEYS_RADIAL_VEHICLEENGINE_LABEL"] = "Motore",

    ["VEHICLEKEYS_RADIAL_REARLEFT_LABEL"] = "Posteriore sinistro",
    ["VEHICLEKEYS_RADIAL_REARRIGHT_LABEL"] = "Posteriore destro",
    ["VEHICLEKEYS_RADIAL_HOOD_LABEL"] = "Cofano",
    ["VEHICLEKEYS_RADIAL_TRUNK_LABEL"] = "Tronco",
    ["VEHICLEKEYS_RADIAL_DRIVER_LABEL"] = "Conducente",
    ["VEHICLEKEYS_RADIAL_PASSENGER_LABEL"] = "Passeggero",

    ["VEHICLEKEYS_COMMAND_ENGINE"] = 'Sblocca/blocca veicolo',
    ["VEHICLEKEYS_COMMAND_USEKEY"] = 'Controllo motore',

    -- Traduzioni di target e negozi

    ["VEHICLEKEYS_PLATE_SHOP_LABEL"] = 'Negozio di piatti',
    ["VEHICLEKEYS_PLATE_SHOP_NAME"] = 'Negozio di piatti',

    ["VEHICLEKEYS_OPEN_PLATE"] = 'Apri negozio',
    ["VEHICLEKEYS_OPEN_PLATE_TARGET_ICON"] = 'fas fa-clipboard',

    ["VEHICLEKEYS_COPY_KEYS"] = 'Copia chiave',
    ["VEHICLEKEYS_COPY_KEYS_TARGET_ICON"] = 'fas fa-copia',

    ["VEHICLEKEYS_OPEN_CLOSE_TARGET"] = 'Apri/Chiudi veicolo',
    ["VEHICLEKEYS_OPEN_CLOSE_TARGET_ICON"] = 'fas fa-chiave',
}
