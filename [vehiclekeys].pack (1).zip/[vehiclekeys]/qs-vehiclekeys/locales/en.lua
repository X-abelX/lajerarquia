Locales["en"] = {
    ["VEHICLEKEYS_MENU_TITLE"] = "Copy of Keys",
    ["VEHICLEKEYS_MENU_MODEL"] = "Model:",
    ["VEHICLEKEYS_MENU_PLATE"] = "Plate:",
    ["VEHICLEKEYS_MENU_CHOICE_TITLE"] = "Menu Choice",
    ["VEHICLEKEYS_MENU_OWNED_VEHICLES"] = "Owned Vehicles",
    ["VEHICLEKEYS_MENU_OWNED_KEYS"] = "Owned Keys",
    ["BACK_TO_PREVIOUS_MENU"] = "Back to Previous Menu",
    ["NO_KEYS_FOUND"] = "No keys found in inventory",

    ["VEHICLEKEYS_DRAWTEXT_COPYKEYS"] = "[E] - Key Copy",
    ["VEHICLEKEYS_DRAWTEXT_PLATE"] = "[E] - Buy a plate",

    ["VEHICLEKEYS_DRAWTEXT_CHARGE"] = "Charge:",

    ["VEHICLEKEYS_NOTIFICATION_NO_VEHICLES"] = "No vehicles nearby",
    ["VEHICLEKEYS_NOTIFICATION_NO_KEYS"] = "You don't have the keys for that vehicle",
    ["VEHICLEKEYS_NOTIFICATION_CHANGE_PLATE"] = "You changed your plate to:",
    ["VEHICLEKEYS_NOTIFICATION_NO_PLATES"] = "You don't have the keys to this vehicle",
    ["VEHICLEKEYS_NOTIFICATION_LOCK"] = "You have locked the vehicle",
    ["VEHICLEKEYS_NOTIFICATION_UNLOCK"] = "You unlocked the vehicle",
    ["VEHICLEKEYS_NOTIFICATION_NO_MONEY"] = "You don't have enough money",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_SUCCESS"] = "You have successfully picked the lock",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_BROKEN"] = "Your pick is broken",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_FAIL"] = "You were unable to lockpick the vehicle",
    ["VEHICLEKEYS_NOTIFICATION_TITLE"] = "Vehicle Theft",
    ["VEHICLEKEYS_NOTIFICATION_POLICE_DISPATCH"] = "I sounded an alarm on:",
    ["VEHICLEKEYS_NOTIFICATION_ALARM"] = "The vehicle alarm has started to sound",
    ["VEHICLEKEYS_NOTIFICATION_NO_POLICES"] = "There are not enough police in the city",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NPC_KEYS"] = "The civilian gave you the keys to his vehicle",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_VEHICLE"] = "You must be in a vehicle to charge your Smartphone",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_KEYS"] = "You don't have the keys for this vehicle",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_BATTERY_FULL"] = "The battery is already 100%",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_CHARGED"] = "Your phone was charged at:",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_PHONE"] = "You don't have a Smartphone to charge",

    ["VEHICLEKEYS_NOTIFICATION_NOT_OWNED"] = "You don't have keys to this vehicle.",

    ["VEHICLEKEYS_HOTWIRE_STEAL"] = "Stealing keys",
    ["VEHICLEKEYS_HOTWIRE_TAKING_KEYS"] = "Taking keys",
    ["VEHICLEKEYS_HOTWIRE"] = "Press H to hotwire.",

    ["VEHICLEKEYS_CHANGING_PLATE"] = 'Change of license plate',
    ["VEHICLEKEYS_MENU_TITLE_PLATE"] = 'Plate Shop',
    ["VEHICLEKEYS_MENU_BUY_PLATE"] = 'Buy a plate',
    ["VEHICLEKEYS_MENU_BUY_SCREWDRIVER"] = 'Buy a screwdriver',
    ["VEHICLEKEYS_MENU_BUY_PLATE_DESCRIPTION"] = 'Buy a plate',
    ["VEHICLEKEYS_MENU_BUY_CHANGEPLATE_DESCRIPTION"] = 'Buy a screwdriver',
    ["VEHICLEKEYS_MENU_NO_CHANGER_ITEM"] = 'No tools',
    ["VEHICLEKEYS_PLATE_LOCKED"] = 'The vehicle is locked!',

    ["VEHICLEKEYS_LOCKPICK_WHITELIST"] = 'The lock of this car can not be opened.',
    ["VEHICLEKEYS_LOCKPICK_UNLOCKED"] = 'This car is not locked.',
    ["VEHICLEKEYS_LOCKPICK_INSIDE"] = 'You can\'t pick a car from the inside.',

    ["ADMINCOMMAND_NO_VEHICLE"] = "You are not in a vehicle",
    ["ADMINCOMMAND_GIVED_VEHICLE"] = "You gave the car keys correctly",
    ["ADMINCOMMAND_PLAYER"] = "Player",
    ["ADMINCOMMAND_HELP"] = "Give Vehicle Keys",
    ["ADMINCOMMAND_COMMAND"] = "givekey",
    ["ADMINCOMMAND_RANGE"] = "admin",
    ["ADMINCOMMAND_NO_PLAYER"] = "ID incorrect",

    ["VEHICLEKEYS_RADIAL_VEHICLE_LABEL"] = "Vehicle",
    ["VEHICLEKEYS_RADIAL_VEHICLEKEYS_LABEL"] = "Keys",
    ["VEHICLEKEYS_RADIAL_VEHICLESEATBELT_LABEL"] = "Seatbelt",
    ["VEHICLEKEYS_RADIAL_VEHICLECHAIRS_LABEL"] = "Seats",
    ["VEHICLEKEYS_RADIAL_VEHICLEWINDOWS_LABEL"] = "Windows",
    ["VEHICLEKEYS_RADIAL_VEHICLEDOORS_LABEL"] = "Doors",
    ["VEHICLEKEYS_RADIAL_VEHICLEENGINE_LABEL"] = "Engine",

    ["VEHICLEKEYS_RADIAL_REARLEFT_LABEL"] = "Back left",
    ["VEHICLEKEYS_RADIAL_REARRIGHT_LABEL"] = "Back right",
    ["VEHICLEKEYS_RADIAL_HOOD_LABEL"] = "Hood",
    ["VEHICLEKEYS_RADIAL_TRUNK_LABEL"] = "Trunk",
    ["VEHICLEKEYS_RADIAL_DRIVER_LABEL"] = "Driver",
    ["VEHICLEKEYS_RADIAL_PASSENGER_LABEL"] = "Passenger",

    ["VEHICLEKEYS_COMMAND_ENGINE"] = "Unlock/Lock Vehicle",
    ["VEHICLEKEYS_COMMAND_USEKEY"] = "Engine control",

    -- Target & Shop translations

    ["VEHICLEKEYS_PLATE_SHOP_LABEL"] = 'Plate shop',
    ["VEHICLEKEYS_PLATE_SHOP_NAME"] = 'Plate shop',

    ["VEHICLEKEYS_OPEN_PLATE"] = 'Open shop',
    ["VEHICLEKEYS_OPEN_PLATE_TARGET_ICON"] = 'fas fa-clipboard',

    ["VEHICLEKEYS_COPY_KEYS"] = 'Key copy',
    ["VEHICLEKEYS_COPY_KEYS_TARGET_ICON"] = 'fas fa-copy',

    ["VEHICLEKEYS_OPEN_CLOSE_TARGET"] = 'Open / Close vehicle',
    ["VEHICLEKEYS_OPEN_CLOSE_TARGET_ICON"] = 'fas fa-key',
}
