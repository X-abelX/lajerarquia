Locales["de"] = {
    ["VEHICLEKEYS_MENU_TITLE"] = "Schlüssel Kopieren",
    ["VEHICLEKEYS_MENU_MODEL"] = "Modell:",
    ["VEHICLEKEYS_MENU_PLATE"] = "Kennzeichen:",

    ["VEHICLEKEYS_DRAWTEXT_COPYKEYS"] = "[E] - Schlüssel Kopieren",
    ["VEHICLEKEYS_DRAWTEXT_PLATE"] = "[E] - Kaufen Sie einen Teller",
    
    ["VEHICLEKEYS_DRAWTEXT_CHARGE"] = "Laden:",

    ["VEHICLEKEYS_NOTIFICATION_NO_VEHICLES"] = "Keine Fahrzeuge in der Nähe",
    ["VEHICLEKEYS_NOTIFICATION_NO_KEYS"] = "Du hast die Schlüssel für dieses Fahrzeug nicht",
    ["VEHICLEKEYS_NOTIFICATION_CHANGE_PLATE"] = "Du hast dein Kennzeichen geändert zu:",
    ["VEHICLEKEYS_NOTIFICATION_NO_PLATES"] = "Du hast die Schlüssel für dieses Fahrzeug nicht",
    ["VEHICLEKEYS_NOTIFICATION_LOCK"] = "Du hast das Fahrzeug verschlossen",
    ["VEHICLEKEYS_NOTIFICATION_UNLOCK"] = "Du hast das Fahrzeug entriegelt",
    ["VEHICLEKEYS_NOTIFICATION_NO_MONEY"] = "Du hast nicht genug Geld",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_SUCCESS"] = "Du hast das Schloss erfolgreich geöffnet",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_BROKEN"] = "Dein Werkzeug ist kaputt",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_FAIL"] = "Du konntest das Fahrzeug nicht aufbrechen",
    ["VEHICLEKEYS_NOTIFICATION_TITLE"] = "Fahrzeugdiebstahl",
    ["VEHICLEKEYS_NOTIFICATION_POLICE_DISPATCH"] = "Ich habe einen Alarm ausgelöst bei:",
    ["VEHICLEKEYS_NOTIFICATION_ALARM"] = "Die Alarmanlage des Fahrzeugs hat zu klingen begonnen",
    ["VEHICLEKEYS_NOTIFICATION_NO_POLICES"] = "Es gibt nicht genug Polizei in der Stadt",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NPC_KEYS"] = "Der Zivilist hat dir die Schlüssel zu seinem Fahrzeug gegeben",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_VEHICLE"] = "Du musst dich in einem Fahrzeug befinden, um dein Smartphone zu laden",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_KEYS"] = "Du hast die Schlüssel für dieses Fahrzeug nicht",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_BATTERY_FULL"] = "Der Akku ist bereits zu 100% geladen",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_CHARGED"] = "Dein Telefon wurde geladen um:",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_PHONE"] = "Du hast kein Smartphone zum Laden",

    ["VEHICLEKEYS_HOTWIRE_STEAL"] = "Schlüssel stehlen",
    ["VEHICLEKEYS_HOTWIRE_TAKING_KEYS"] = "Schlüssel nehmen",
    ["VEHICLEKEYS_HOTWIRE"] = "Drücke H zum Heißverdrahten",

    ["VEHICLEKEYS_CHANGING_PLATE"] = 'Kennzeichenwechsel',
    ["VEHICLEKEYS_MENU_TITLE_PLATE"] = 'Plattenladen',
    ["VEHICLEKEYS_MENU_BUY_PLATE"] = 'Ein Kennzeichen kaufen',
    ["VEHICLEKEYS_MENU_BUY_PLATE_DESCRIPTION"] = 'Ein Kennzeichen kaufen für: $',
    ["VEHICLEKEYS_MENU_BUY_CHANGEPLATE_DESCRIPTION"] = 'Schraubendreher kaufen für: $',
    ["VEHICLEKEYS_MENU_NO_CHANGER_ITEM"] = 'Keine Werkzeuge',
    ["VEHICLEKEYS_PLATE_LOCKED"] = 'Das Fahrzeug ist verriegelt!',

    ["VEHICLEKEYS_LOCKPICK_WHITELIST"] = 'Das Schloss dieses Autos kann nicht geöffnet werden',

    ["ADMINCOMMAND_NO_VEHICLE"] = "Du bist nicht in einem Fahrzeug",
    ["ADMINCOMMAND_GIVED_VEHICLE"] = "Du hast die Autoschlüssel erfolgreich übergeben",
    ["ADMINCOMMAND_PLAYER"] = "Spieler",
    ["ADMINCOMMAND_HELP"] = "Fahrzeugschlüssel geben",
    ["ADMINCOMMAND_COMMAND"] = "schlüsselgeben",
    ["ADMINCOMMAND_RANGE"] = "admin",
    ["ADMINCOMMAND_NO_PLAYER"] = "Falsche ID",

    ["VEHICLEKEYS_RADIAL_VEHICLE_LABEL"] = "Fahrzeug",
    ["VEHICLEKEYS_RADIAL_VEHICLEKEYS_LABEL"] = "Schlüssel",
    ["VEHICLEKEYS_RADIAL_VEHICLESEATBELT_LABEL"] = "Gürtel",
    ["VEHICLEKEYS_RADIAL_VEHICLECHAIRS_LABEL"] = "Sitze",
    ["VEHICLEKEYS_RADIAL_VEHICLEWINDOWS_LABEL"] = "Windows",
    ["VEHICLEKEYS_RADIAL_VEHICLEDOORS_LABEL"] = "Türen",
    ["VEHICLEKEYS_RADIAL_VEHICLEENGINE_LABEL"] = "Motor",

    ["VEHICLEKEYS_RADIAL_REARLEFT_LABEL"] = "Hinten links",
    ["VEHICLEKEYS_RADIAL_REARRIGHT_LABEL"] = "Rechts hinten",
    ["VEHICLEKEYS_RADIAL_HOOD_LABEL"] = "Motorhaube",
    ["VEHICLEKEYS_RADIAL_TRUNK_LABEL"] = "Kofferraum",
    ["VEHICLEKEYS_RADIAL_DRIVER_LABEL"] = "Fahrer",
    ["VEHICLEKEYS_RADIAL_PASSENGER_LABEL"] = "Passagier",

    ["VEHICLEKEYS_COMMAND_ENGINE"] = 'Fahrzeug entriegeln/verriegeln',
    ["VEHICLEKEYS_COMMAND_USEKEY"] = 'Motorsteuerung',

    -- Target und Shop-Übersetzungen

    ["VEHICLEKEYS_PLATE_SHOP_LABEL"] = 'Plattenladen',
    ["VEHICLEKEYS_PLATE_SHOP_NAME"] = 'Plattenladen',

    ["VEHICLEKEYS_OPEN_PLATE"] = 'Shop öffnen',
    ["VEHICLEKEYS_OPEN_PLATE_TARGET_ICON"] = 'fas fa-clipboard',

    ["VEHICLEKEYS_COPY_KEYS"] = 'Schlüssel kopieren',
    ["VEHICLEKEYS_COPY_KEYS_TARGET_ICON"] = 'fas fa-copy',

    ["VEHICLEKEYS_OPEN_CLOSE_TARGET"] = 'Fahrzeug öffnen/schließen',
    ["VEHICLEKEYS_OPEN_CLOSE_TARGET_ICON"] = 'fas fa-key',
}
