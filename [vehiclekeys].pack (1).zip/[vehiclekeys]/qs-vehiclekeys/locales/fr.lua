Locales["fr"] = {
    ["VEHICLEKEYS_MENU_TITLE"] = "Copie de clé",
    ["VEHICLEKEYS_MENU_MODEL"] = "Modèle :",
    ["VEHICLEKEYS_MENU_PLATE"] = "Plaque :",
    ["VEHICLEKEYS_MENU_CHOICE_TITLE"] = "Choix du menu",
    ["VEHICLEKEYS_MENU_OWNED_VEHICLES"] = "Véhicules possédés",
    ["VEHICLEKEYS_MENU_OWNED_KEYS"] = "Clés possédées",
    ["BACK_TO_PREVIOUS_MENU"] = "Retour au menu précédent",
    ["NO_KEYS_FOUND"] = "Aucune clé trouvée dans l'inventaire",

    ["VEHICLEKEYS_DRAWTEXT_COPYKEYS"] = "E - Copier la clé",
    ["VEHICLEKEYS_DRAWTEXT_PLATE"] = "E - Acheter une plaque",

    ["VEHICLEKEYS_DRAWTEXT_CHARGE"] = "Charger :",

    ["VEHICLEKEYS_NOTIFICATION_NO_VEHICLES"] = "Pas de véhicules à proximité...",
    ["VEHICLEKEYS_NOTIFICATION_NO_PLATE_IN_CAR"] = "Vous ne pouvez pas utiliser une plaque depuis un véhicule.",
    ["VEHICLEKEYS_NOTIFICATION_NO_KEYS"] = "Vous n'avez pas les clés de ce véhicule...",
    ["VEHICLEKEYS_NOTIFICATION_CHANGE_PLATE"] = "Vous avez changé votre plaque d'immatriculation en :",
    ["VEHICLEKEYS_NOTIFICATION_NO_PLATES"] = "Vous n'avez pas les clés de ce véhicule...",
    ["VEHICLEKEYS_NOTIFICATION_LOCK"] = "Vous avez verrouillé le véhicule.",
    ["VEHICLEKEYS_NOTIFICATION_UNLOCK"] = "Vous avez déverrouillé le véhicule.",
    ["VEHICLEKEYS_NOTIFICATION_NO_MONEY"] = "Vous n'avez pas assez d'argent...",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_SUCCESS"] = "Vous avez réussi à crocheter la serrure !",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_BROKEN"] = "Votre crochet est cassé !",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_FAIL"] = "Vous n'avez pas réussi à crocheter le véhicule...",
    ["VEHICLEKEYS_NOTIFICATION_TITLE"] = "Vol de véhicule",
    ["VEHICLEKEYS_NOTIFICATION_POLICE_DISPATCH"] = "J'ai déclenché une alarme sur :",
    ["VEHICLEKEYS_NOTIFICATION_ALARM"] = "L'alarme du véhicule a commencé à retentir !",
    ["VEHICLEKEYS_NOTIFICATION_NO_POLICES"] = "Il n'y a pas assez de policiers en ville...",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NPC_KEYS"] = "Le civil vous a donné les clés de son véhicule !",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_VEHICLE"] = "Vous devez être dans un véhicule pour charger votre smartphone.",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_KEYS"] = "Vous n'avez pas les clés de ce véhicule...",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_BATTERY_FULL"] = "La batterie est déjà à 100 %",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_CHARGED"] = "Votre téléphone a été chargé à :",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_PHONE"] = "Vous n'avez pas de smartphone à charger.",

    ["VEHICLEKEYS_NOTIFICATION_NOT_OWNED"] = "Vous n'avez pas les cléfs de ce véhicule.",

    ["VEHICLEKEYS_HOTWIRE_STEAL"] = "Vol de clés",
    ["VEHICLEKEYS_HOTWIRE_TAKING_KEYS"] = "Récupération des clés",
    ["VEHICLEKEYS_HOTWIRE"] = "H - Récupérer les cléfs",

    ["VEHICLEKEYS_CHANGING_PLATE"] = 'Changement de plaque d\'immatriculation',
    ["VEHICLEKEYS_MENU_TITLE_PLATE"] = 'Boutique de plaques',
    ["VEHICLEKEYS_MENU_BUY_PLATE"] = 'Acheter une plaque',
    ["VEHICLEKEYS_MENU_BUY_PLATE_DESCRIPTION"] = 'Acheter une plaque',
    ["VEHICLEKEYS_MENU_BUY_CHANGEPLATE_DESCRIPTION"] = 'Acheter un tournevis',
    ["VEHICLEKEYS_MENU_NO_CHANGER_ITEM"] = 'Aucun outil',
    ["VEHICLEKEYS_PLATE_LOCKED"] = 'Le véhicule est vérouillé !',

    ["VEHICLEKEYS_LOCKPICK_WHITELIST"] = 'La serrure de cette voiture ne peut pas être ouverte.',
    ["VEHICLEKEYS_LOCKPICK_UNLOCKED"] = 'Cette voiture n\'est pas verrouillée.',
    ["VEHICLEKEYS_LOCKPICK_INSIDE"] = 'Vous ne pouvez pas crocheter une voiture depuis l\'intérieur.',

    ["ADMINCOMMAND_NO_VEHICLE"] = "Vous n'êtes pas dans un véhicule",
    ["ADMINCOMMAND_GIVED_VEHICLE"] = "Vous avez correctement donné les clés du véhicule",
    ["ADMINCOMMAND_PLAYER"] = "Joueur",
    ["ADMINCOMMAND_HELP"] = "Donner les clés du véhicule",
    ["ADMINCOMMAND_COMMAND"] = "adminkeys",
    ["ADMINCOMMAND_RANGE"] = "admin",
    ["ADMINCOMMAND_NO_PLAYER"] = "ID incorrect",

    ["VEHICLEKEYS_RADIAL_VEHICLE_LABEL"] = "Véhicule",
    ["VEHICLEKEYS_RADIAL_VEHICLEKEYS_LABEL"] = "Cléfs",
    ["VEHICLEKEYS_RADIAL_VEHICLESEATBELT_LABEL"] = "Ceinture",
    ["VEHICLEKEYS_RADIAL_VEHICLECHAIRS_LABEL"] = "Sièges",
    ["VEHICLEKEYS_RADIAL_VEHICLEWINDOWS_LABEL"] = "Fenêtres",
    ["VEHICLEKEYS_RADIAL_VEHICLEDOORS_LABEL"] = "Portes",
    ["VEHICLEKEYS_RADIAL_VEHICLEENGINE_LABEL"] = "Moteur",

    ["VEHICLEKEYS_RADIAL_REARLEFT_LABEL"] = "Arrière gauche",
    ["VEHICLEKEYS_RADIAL_REARRIGHT_LABEL"] = "Arrière droite",
    ["VEHICLEKEYS_RADIAL_HOOD_LABEL"] = "Capôt",
    ["VEHICLEKEYS_RADIAL_TRUNK_LABEL"] = "Coffre",
    ["VEHICLEKEYS_RADIAL_DRIVER_LABEL"] = "Conducteur",
    ["VEHICLEKEYS_RADIAL_PASSENGER_LABEL"] = "Passager",

    ["VEHICLEKEYS_COMMAND_ENGINE"] = 'Déverrouiller/verrouiller le véhicule',
    ["VEHICLEKEYS_COMMAND_USEKEY"] = 'Contrôle moteur',

    ["VEHICLEKEYS_PLATE_SHOP_LABEL"] = 'Boutique de plaques',
    ["VEHICLEKEYS_PLATE_SHOP_NAME"] = 'Boutique de plaques',

    ["VEHICLEKEYS_OPEN_PLATE"] = 'Ouvrir le magasin',
    ["VEHICLEKEYS_OPEN_PLATE_TARGET_ICON"] = 'fas fa-clipboard',

    ["VEHICLEKEYS_COPY_KEYS"] = 'Copie de clé',
    ["VEHICLEKEYS_COPY_KEYS_TARGET_ICON"] = 'fas fa-copy',

    ["VEHICLEKEYS_OPEN_CLOSE_TARGET"] = 'Ouvrir / Fermer le véhicule',
    ["VEHICLEKEYS_OPEN_CLOSE_TARGET_ICON"] = 'fas fa-key',

    ["VEHICLEKEYS_PLATE_TARGET_LABEL"] = 'Changer de plaque',
    ["VEHICLEKEYS_PLATE_TARGET_ICON"] = 'fas fa-screwdriver',

}
