Locales["es"] = {
    ["VEHICLEKEYS_MENU_TITLE"] = "Copia de llave",
    ["VEHICLEKEYS_MENU_MODEL"] = "Modelo:",
    ["VEHICLEKEYS_MENU_PLATE"] = "Placa:",
    ["VEHICLEKEYS_MENU_CHOICE_TITLE"] = "Elección de menú",
    ["VEHICLEKEYS_MENU_OWNED_VEHICLES"] = "Vehículos propios",
    ["VEHICLEKEYS_MENU_OWNED_KEYS"] = "Llaves propias",
    ["BACK_TO_PREVIOUS_MENU"] = "Volver al menú anterior",
    ["NO_KEYS_FOUND"] = "No se encontraron llaves en el inventario",

    ["VEHICLEKEYS_DRAWTEXT_COPYKEYS"] = "[E] - Copiar Llave",
    ["VEHICLEKEYS_DRAWTEXT_PLATE"] = "[E] - Comprar una placa",

    ["VEHICLEKEYS_DRAWTEXT_CHARGE"] = "Carga:",

    ["VEHICLEKEYS_NOTIFICATION_NO_VEHICLES"] = "No hay vehículos cerca",
    ["VEHICLEKEYS_NOTIFICATION_NO_KEYS"] = "No tienes las llaves de ese vehículo",
    ["VEHICLEKEYS_NOTIFICATION_CHANGE_PLATE"] = "Cambiaste tu matrícula a:",
    ["VEHICLEKEYS_NOTIFICATION_NO_PLATES"] = "No tienes las llaves de este vehículo",
    ["VEHICLEKEYS_NOTIFICATION_LOCK"] = "Has bloqueado el vehículo",
    ["VEHICLEKEYS_NOTIFICATION_UNLOCK"] = "Has desbloqueado el vehículo",
    ["VEHICLEKEYS_NOTIFICATION_NO_MONEY"] = "No tienes suficiente dinero",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_SUCCESS"] = "Has logrado abrir la cerradura",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_BROKEN"] = "Tu ganzúa está rota",
    ["VEHICLEKEYS_NOTIFICATION_LOCKPICK_FAIL"] = "No pudiste abrir la cerradura",
    ["VEHICLEKEYS_NOTIFICATION_TITLE"] = "Robo de Vehículo",
    ["VEHICLEKEYS_NOTIFICATION_POLICE_DISPATCH"] = "He activado una alarma en:",
    ["VEHICLEKEYS_NOTIFICATION_ALARM"] = "La alarma del vehículo ha empezado a sonar",
    ["VEHICLEKEYS_NOTIFICATION_NO_POLICES"] = "No hay suficientes policías en la ciudad",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NPC_KEYS"] = "El civil te ha dado las llaves de su vehículo",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_VEHICLE"] = "Debes estar en un vehículo para cargar tu teléfono",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_KEYS"] = "No tienes las llaves de este vehículo",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_BATTERY_FULL"] = "La batería ya está al 100%",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_CHARGED"] = "Tu teléfono se cargó en:",
    ["VEHICLEKEYS_NOTIFICATION_CHARGE_NO_PHONE"] = "No tienes un Smartphone para cargar",
    ["VEHICLEKEYS_NOTIFICATION_NOT_OWNED"] = "No tienes llaves para este vehiculo",

    ["VEHICLEKEYS_HOTWIRE_STEAL"] = "Robando llaves",
    ["VEHICLEKEYS_HOTWIRE_TAKING_KEYS"] = "Tomando llaves",
    ["VEHICLEKEYS_HOTWIRE"] = "Presiona H para encender con cables",

    ["VEHICLEKEYS_CHANGING_PLATE"] = 'Cambio de matrícula',
    ["VEHICLEKEYS_MENU_TITLE_PLATE"] = 'Tienda de platos',
    ["VEHICLEKEYS_MENU_BUY_PLATE"] = 'Comprar un plato',
    ["VEHICLEKEYS_MENU_BUY_PLATE_DESCRIPTION"] = 'Compre un plato por',
    ["VEHICLEKEYS_MENU_BUY_CHANGEPLATE_DESCRIPTION"] = 'Compre un destornillador',
    ["VEHICLEKEYS_MENU_NO_CHANGER_ITEM"] = 'Sin herramientas',
    ["VEHICLEKEYS_PLATE_LOCKED"] = '¡El vehículo está bloqueado!',

    ["VEHICLEKEYS_LOCKPICK_WHITELIST"] = 'La cerradura de este auto no puede ser abierta',
    ["VEHICLEKEYS_LOCKPICK_UNLOCKED"] = 'Este coche no está cerrado.',
    ["VEHICLEKEYS_LOCKPICK_INSIDE"] = 'No puedes forzar un coche desde el interior.',

    ["ADMINCOMMAND_NO_VEHICLE"] = "No estás en un vehículo",
    ["ADMINCOMMAND_GIVED_VEHICLE"] = "Has entregado las llaves del auto correctamente",
    ["ADMINCOMMAND_PLAYER"] = "Jugador",
    ["ADMINCOMMAND_HELP"] = "Dar Llaves de Vehículo",
    ["ADMINCOMMAND_COMMAND"] = "darllave",
    ["ADMINCOMMAND_RANGE"] = "admin",
    ["ADMINCOMMAND_NO_PLAYER"] = "ID incorrecta",

    ["VEHICLEKEYS_RADIAL_VEHICLE_LABEL"] = "Vehículo",
    ["VEHICLEKEYS_RADIAL_VEHICLEKEYS_LABEL"] = "Claves",
    ["VEHICLEKEYS_RADIAL_VEHICLESEATBELT_LABEL"] = "Cinturón",
    ["VEHICLEKEYS_RADIAL_VEHICLECHAIRS_LABEL"] = "Asientos",
    ["VEHICLEKEYS_RADIAL_VEHICLEWINDOWS_LABEL"] = "Windows",
    ["VEHICLEKEYS_RADIAL_VEHICLEDOORS_LABEL"] = "Puertas",
    ["VEHICLEKEYS_RADIAL_VEHICLEENGINE_LABEL"] = "Motor",

    ["VEHICLEKEYS_RADIAL_REARLEFT_LABEL"] = "Trasero izquierdo",
    ["VEHICLEKEYS_RADIAL_REARRIGHT_LABEL"] = "Trasero derecho",
    ["VEHICLEKEYS_RADIAL_HOOD_LABEL"] = "Capó",
    ["VEHICLEKEYS_RADIAL_TRUNK_LABEL"] = "Maletero",
    ["VEHICLEKEYS_RADIAL_DRIVER_LABEL"] = "Conductor",
    ["VEHICLEKEYS_RADIAL_PASSENGER_LABEL"] = "Pasajero",

    ["VEHICLEKEYS_COMMAND_ENGINE"] = 'Desbloquear/bloquear vehículo',
    ["VEHICLEKEYS_COMMAND_USEKEY"] = 'Control del motor',

    -- Traducciones de Target y Shop

    ["VEHICLEKEYS_PLATE_SHOP_LABEL"] = 'Tienda de platos',
    ["VEHICLEKEYS_PLATE_SHOP_NAME"] = 'Tienda de platos',

    ["VEHICLEKEYS_OPEN_PLATE"] = 'Abrir tienda',
    ["VEHICLEKEYS_OPEN_PLATE_TARGET_ICON"] = 'fas fa-portapapeles',

    ["VEHICLEKEYS_COPY_KEYS"] = 'Copiar clave',
    ["VEHICLEKEYS_COPY_KEYS_TARGET_ICON"] = 'fas fa-copia',

    ["VEHICLEKEYS_OPEN_CLOSE_TARGET"] = 'Abrir/Cerrar vehículo',
    ["VEHICLEKEYS_OPEN_CLOSE_TARGET_ICON"] = 'fas fa-key',
}
