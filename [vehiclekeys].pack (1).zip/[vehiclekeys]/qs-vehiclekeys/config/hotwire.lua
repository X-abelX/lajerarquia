-- ██╗░░██╗░█████╗░████████╗░██╗░░░░░░░██╗██╗██████╗░███████╗
-- ██║░░██║██╔══██╗╚══██╔══╝░██║░░██╗░░██║██║██╔══██╗██╔════╝
-- ███████║██║░░██║░░░██║░░░░╚██╗████╗██╔╝██║██████╔╝█████╗░░
-- ██╔══██║██║░░██║░░░██║░░░░░████╔═████║░██║██╔══██╗██╔══╝░░
-- ██║░░██║╚█████╔╝░░░██║░░░░░╚██╔╝░╚██╔╝░██║██║░░██║███████╗
-- ╚═╝░░╚═╝░╚════╝░░░░╚═╝░░░░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝

-- Disable hotwiring if not configured
if not Config.Hotwire then
    exports["qs-vehiclekeys"]:disableHotwire(true)
    TextClose()
end

if not lib then print('You are missing ox_lib please install it ! It is listed as a necessary dependency for this script to work.') return end

function MiniGameHotWire(state)
    if Config.MiniGameHotWireStyle == "easy" then
        local success = lib.skillCheck({"easy", "easy", "easy", "easy", "easy"})
        -- The part under this should not be edited, it will most likely break the Hotwire.
        if success then
            TextClose()
            inHotwire = false
            Hotwire(state)
        else
            isTextVisible = true
            inHotwire = true
            inMinigame = false
            initKeys(state)
        end
    end
    if Config.MiniGameHotWireStyle == "hard" then
        local success = lib.skillCheck({"easy", "easy", {areaSize = 70, speedMultiplier = 1}, "easy"}, {"z", "q", "s", "d"})
        -- The part under this should not be edited, it will most likely break the Hotwire.
        if success then
            TextClose()
            inHotwire = false
            Hotwire(state)
        else
            isTextVisible = true
            inHotwire = true
            initKeys(state)
        end
    end
end

-- Function to show custom progress bars during hotwiring when taking keys
function CustomProgBarsHotWire(plates, vehicle_model, coords, time)
    -- Check if the progress circle is successfully created
    if lib.progressCircle({
        duration = time,
        position = "bottom",
        label = Lang("VEHICLEKEYS_HOTWIRE_TAKING_KEYS"),
        useWhileDead = false,
        disable = {
            car = true
        },
        anim = {
            dict = "anim@amb@clubhouse@tutorial@bkr_tut_ig3@",
            clip = "machinic_loop_mechandplayer"
        }
    }) then
        -- Trigger server event to give keys and clear player tasks
        TriggerServerEvent(Config.Eventprefix .. ":server:givekey", plates, vehicle_model)
        ClearPedTasks(PlayerPedId())
        -- Wait for a short duration before notifying the cops
        Wait(5000)
        TriggerServerEvent(Config.Eventprefix .. ":server:notifyCops", coords)
    end
end

-- Function to show custom progress bars when taking keys from a dead pedestrian
function CustomProgBarsDeadPed(plates, vehicle_model)
    -- Check if the progress circle is successfully created
    if lib.progressCircle({
        position = "bottom",
        duration = 10000,
        label = Lang("VEHICLEKEYS_HOTWIRE_STEAL"),
        useWhileDead = false,
        disable = {
            car = true
        },
        anim = {
            dict = "missheistdockssetup1clipboard@idle_a",
            clip = "idle_a"
        }
    }) then
        -- Clear player tasks and trigger server event to give keys
        ClearPedTasks(PlayerPedId())
        TriggerServerEvent(Config.Eventprefix .. ":server:givekey", plates, vehicle_model)
    end
end
