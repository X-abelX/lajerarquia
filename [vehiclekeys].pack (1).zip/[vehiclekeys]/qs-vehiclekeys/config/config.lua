Config = Config or {}
Locales = Locales or {}

--[[
    Welcome to the qs-vehiclekeys configuration!
    To start configuring your new asset, please read carefully
    each step in the documentation that we will attach at the end of this message.

    Each important part of the configuration will be highlighted with a box.
    like this one you are reading now, where I will explain step by step each
    configuration available within this file.

    This is not all, most of the settings, you are free to modify it
    as you wish and adapt it to your framework in the most comfortable way possible.
    The configurable files you will find all inside client/custom/*
    or inside server/custom/*.

    Direct link to the resource documentation, read it before you start:
    https://docs.quasar-store.com/information/welcome
]]

-- ███████╗██████╗░░█████╗░███╗░░░███╗███████╗░██╗░░░░░░░██╗░█████╗░██████╗░██╗░░██╗
-- ██╔════╝██╔══██╗██╔══██╗████╗░████║██╔════╝░██║░░██╗░░██║██╔══██╗██╔══██╗██║░██╔╝
-- █████╗░░██████╔╝███████║██╔████╔██║█████╗░░░╚██╗████╗██╔╝██║░░██║██████╔╝█████═╝░
-- ██╔══╝░░██╔══██╗██╔══██║██║╚██╔╝██║██╔══╝░░░░████╔═████║░██║░░██║██╔══██╗██╔═██╗░
-- ██║░░░░░██║░░██║██║░░██║██║░╚═╝░██║███████╗░░╚██╔╝░╚██╔╝░╚█████╔╝██║░░██║██║░╚██╗
-- ╚═╝░░░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░░░░╚═╝╚══════╝░░░╚═╝░░░╚═╝░░░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝

Config.Framework = 'esx' -- You can choose between 'esx' or 'qb'.
Config.Language = 'en'   -- Available languages by default: 'es', 'en' and 'fr' you can create more if you wish.

--[[
 █ █▄░█ █░█ █▀▀ █▄░█ ▀█▀ █▀█ █▀█ █▄█
 █ █░▀█ ▀▄▀ ██▄ █░▀█ ░█░ █▄█ █▀▄ ░█░
]]

-- Choose from the following options.
    --[[
        'qs' for qs-inventory
        'qb' for qb-inventory
        'core_inventory',
        'ox' for
    ]]
Config.InventoryScript = 'qs'

Config.PersistantCheck = true -- If true, the script will always check if the player has keys for the vehicle the player is in. 
Config.PersistantCheckTime = 1250 -- Time in MS at which intervals the check should be executed !!! The lower the number, the more will the performance be impacted !!!

--[[
 █▀▄▀█ █▀▀ █▄░█ █░█   ▀█▀ █▄█ █▀█ █▀▀
 █░▀░█ ██▄ █░▀█ █▄█   ░█░ ░█░ █▀▀ ██▄
]]

-- Choose from the following options.
    --[[
        'ox_lib',
        'esx_context',
        'esx_menu_default',
        'qb'
    ]]
Config.MenuType = 'ox_lib' -- Menu type that you will want to use. (Mainly for the copy of the keys and the buying of the plate, if you haven't selected the shop option.)

--[[
 ▀█▀ █▀▀ ▀▄▀ ▀█▀   █░█ █
 ░█░ ██▄ █░█ ░█░   █▄█ █
]]

-- Choose from the following options.
    --[[
        'Draw3DText',
        'HelpNotification', --Basic FiveM HelpNotification
        'ox_lib', -- Most optimized.
        'esx_textui', -- not tested on the moment, please report any issues it will be fixed asap !
        'qb', -- not tested on the moment, please report any issues it will be fixed asap !
        'okokTextUI', -- Most optimized. (A bit loud...)
    ]]
Config.TextUI = 'ox_lib' -- TextUI shown while getting close to the Peds, for copy of the keys and the buying of the plate.

--[[
 ▀█▀ ▄▀█ █▀█ █▀▀ █▀▀ ▀█▀
 ░█░ █▀█ █▀▄ █▄█ ██▄ ░█░
]]

-- Will be improved on fruther...
-- Installing of the plate trough target, stealing peds and much more are coming !
Config.EnableTarget = false -- Used for lock / unlocked of the cars, and for copy of the keys and the buying of the plate. (If enabled it will override the options of the TextUI)
Config.Target = {
-- Choose from the following options.
    --[[
        'qb' (qb-target)
        'ox' (ox_target)
    ]]
    TargetName = 'ox',
    distance = 2.0 -- Distance
}

--[[
 █▀█ ▄▀█ █▀▄ █ ▄▀█ █░░
 █▀▄ █▀█ █▄▀ █ █▀█ █▄▄
]]

Config.Radial = 'ox' -- Optional radial menu, for car managements, locking car and EngineControl supporting ox default radial menu.
-- Choose from the following options.
--[[
    'ox' (ox_lib)

    false (Disable fully the use of the radial menus)
]]


-- ░██████╗░███████╗███╗░░██╗███████╗██████╗░░█████╗░██╗░░░░░
-- ██╔════╝░██╔════╝████╗░██║██╔════╝██╔══██╗██╔══██╗██║░░░░░
-- ██║░░██╗░█████╗░░██╔██╗██║█████╗░░██████╔╝███████║██║░░░░░
-- ██║░░╚██╗██╔══╝░░██║╚████║██╔══╝░░██╔══██╗██╔══██║██║░░░░░
-- ██████╔╝███████╗ ██║░╚███║███████╗██║░░██║██║░░██║███████╗
-- ░╚═════╝░╚══════╝╚═╝░░╚══╝╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝

Config.NpcVehiclesLocked = false -- Do you want npc vehicles spawned by GTA V to be blocked?

Config.SendNotification = true -- True will send a notification when you open / close the vehicle. False will not send a notification.
Config.ReplaceDraw3D = true -- True will replace the hotwire DrawText3D with the custom function from qs-vehiclekeys/client/custom/misc/Draw3DText.lua
Config.CustomDesignTextUI = true -- Enable/disable custom design for the text UI
Config.CustomIcon = 'screwdriver-wrench' -- Specify the Font Awesome icon class, set to empty string for no custom icon https://fontawesome.com/

--[[
█▀▀ █▀█ █▄░█ ▀█▀ █▀█ █▀█ █░░ █▀
█▄▄ █▄█ █░▀█ ░█░ █▀▄ █▄█ █▄▄ ▄█
]]

-- client/custom/misc/commands.lua
-- List for the fivem keybinds if you want to change it. https://docs.fivem.net/docs/game-references/input-mapper-parameter-ids/keyboard/
Config.HotKeys = true -- Enable or disable the engine on/off system.
Config.Controls = {
    EngineControl = 'IOM_WHEEL_UP', -- Key to start or stop the engine. (Mouse wheel up) for better compatibility with the qs-dispatch already using the G keybind. And also better roleplay
    UseKey = 'U', -- Key to lock / unlock the car.
}

Config.Hotwire = true -- True or false for enable / disable the hotwire functions.
Config.UseHotwire = 'H' -- Key to start hotwiring the car.


-- ██╗░░██╗███████╗██╗░░░██╗░██████╗
-- ██║░██╔╝██╔════╝╚██╗░██╔╝██╔════╝
-- █████═╝░█████╗░░░╚████╔╝░╚█████╗░
-- ██╔═██╗░██╔══╝░░░░╚██╔╝░░░╚═══██╗
-- ██║░╚██╗███████╗░░░██║░░░██████╔╝
-- ╚═╝░░╚═╝╚══════╝░░░╚═╝░░░╚═════╝░

Config.VehicleKeysItem = 'vehiclekeys' -- Name of the item with metadata to open the vehicle.
Config.LockDistance = 20.0
Config.Anim = 'fob_click_fp' -- Modify the animation when opening or closing the vehicle here.
Config.Animdict = 'anim@mp_player_intmenu@key_fob@' -- Modify the animation when opening or closing the vehicle here.
Config.Keymodel = 'p_car_keys_01' -- Modify the prop when opening or closing the vehicle here.

--[[
█▀▀ █░█ █▀ ▀█▀ █▀█ █▀▄▀█   █▀ █▀█ █░█ █▄░█ █▀▄ █▀
█▄▄ █▄█ ▄█ ░█░ █▄█ █░▀░█   ▄█ █▄█ █▄█ █░▀█ █▄▀ ▄█
]]

-- Dependency of InteractSound needed for this to work !
-- link here : https://github.com/plunkettscott/interact-sound
--[[

1. -- * Place this sound on the interact-sound folder like shown below :

dir : interact-sound/client/html/sounds/carkeys.ogg

2. -- * Add the file name to the fxmanifest.lua file of the interact-sound ressource.

Like shown below (This is only an example, you could have more sounds listed here):

-- Files needed for NUI
-- DON'T FORGET TO ADD THE SOUND FILES TO THIS!
files {
    'client/html/index.html',
    'client/html/sounds/demo.ogg',
    '/client/html/sounds/carkeys.ogg',
}
]]

Config.Sounds = true -- Use of custom sounds through InteractSound
Config.SoundsDisableDefault = false -- Disable the use of Fivem Default sounds.
Config.SoundsVolume = 0.3 -- Distance on where the sound can be heard
Config.SoundsFileName = 'carkeys' -- Name of the file
Config.SoundsDistance = 2 -- Distance on where the sound can be heard

Config.RentalPaperItem = 'rentalpaper' -- Name of the item with metadata for the rentalpaper.

--[[
█▀▀ █▀█ █▀█ █▄█   █▄▀ █▀▀ █▄█ █▀
█▄▄ █▄█ █▀▀ ░█░   █░█ ██▄ ░█░ ▄█
]]

Config.CopyKeysMenu = true --- If you want to use the esx getdistancebetweencoords menu, otherwhise you can make it work with qtarget, the function to open menu is OpenCopyKeys()
Config.OpenCopyKeys = 'E' -- Key to open the key copy menu.
Config.MenuPlacement = 'top-left' -- Position of `esx_menu_default`.
Config.CopyKeysCost = 500 -- Price of the copies of the keys, you can use 0 and it will be free.
Config.InventoryCopyKeysCost = 250 -- Price of the copies of the keys, you can use 0 and it will be free.
Config.CopyKeysLocations = { -- List of stores to copy keys.
	vector3(-31.402076721191, -1647.4393310547, 29.282875061035)
}

Config.Blip = true -- True or false for disable the blip.
Config.CopyKeysBlip = { -- Blip of the key copy spot.
	BlipName = 'Copy keys',
	BlipSprite = 186,
	BlipColour = 3,
	BlipScale = 0.8,
}

-- ██████╗░██╗░░░░░░█████╗░████████╗███████╗░██████╗
-- ██╔══██╗██║░░░░░██╔══██╗╚══██╔══╝██╔════╝██╔════╝
-- ██████╔╝██║░░░░░███████║░░░██║░░░█████╗░░╚█████╗░
-- ██╔═══╝░██║░░░░░██╔══██║░░░██║░░░██╔══╝░░░╚═══██╗
-- ██║░░░░░███████╗██║░░██║░░░██║░░░███████╗██████╔╝
-- ╚═╝░░░░░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═════╝░

--[[
█▀█ █░░ ▄▀█ ▀█▀ █▀▀   █▀ ▀█▀ █▄█ █░░ █▀▀
█▀▀ █▄▄ █▀█ ░█░ ██▄   ▄█ ░█░ ░█░ █▄▄ ██▄
]]

Config.PlateLetters = 3 -- Modify here the type of plate.
Config.PlateNumbers = 3 -- Modify here the type of plate.
Config.PlateUseSpace = true -- Modify here the type of plate.
Config.TimeToChange = 5000 -- Time to change the plate (ms)

--[[
█▀ █░█ █▀█ █▀█
▄█ █▀█ █▄█ █▀▀
]]

Config.PlateType = 'menu' -- Shop or Menu
-- Choose from the following options.
    --[[
        'shop' (qs-shop)
        'menu' (menu defined above)
    ]]


-- Both of these items will be present in the shop or menu accessible through Peds.
-- For ESX account should be money, for qbcore it should be cash or bank.

-- Choose from the following options. For the account.
    --[[
        'money' (ESX ONLY)
        'cash' (QBCORE ONLY)
        'bank' (BOTH)
    ]]

Config.PlateItem = 'plate' -- Name of the item plate.
Config.PlatePrice = {
    price = 500,
    account = 'money',
}

Config.ChangePlateItem = 'screwdriver' -- Item required to use the plate.
Config.ChangePlateItemPrice = {
    price = 150,
    account = 'money',
}


-- ████████╗██╗░░██╗███████╗███████╗████████╗░██████╗
-- ╚══██╔══╝██║░░██║██╔════╝██╔════╝╚══██╔══╝██╔════╝
-- ░░░██║░░░███████║█████╗░░█████╗░░░░░██║░░░╚█████╗░
-- ░░░██║░░░██╔══██║██╔══╝░░██╔══╝░░░░░██║░░░░╚═══██╗
-- ░░░██║░░░██║░░██║███████╗██║░░░░░░░░██║░░░██████╔╝
-- ░░░╚═╝░░░╚═╝░░╚═╝╚══════╝╚═╝░░░░░░░░╚═╝░░░╚═════╝░

-- You can edit here : qs-vehiclekeys/config/hotwire.lua
-- Find the ox_lib skillCheck documentation listed below :
-- https://overextended.dev/ox_lib/Modules/Interface/Client/skillcheck

Config.MiniGameHotWireStyle = 'easy' -- Available Style 'easy' or 'hard'

--[[
'easy' = lib.skillCheck({'easy', 'easy', 'easy', 'easy', 'easy'})
'hard' = lib.skillCheck({'easy', 'easy', {areaSize=70, speedMultiplier=1}, 'easy'}, {'z', 'q', 's', 'd'})
]]

Config.TimeMin = 1000 -- Minimum time to hotwire
Config.TimeMax = 5000 -- Maximun time to hotwire
Config.ChanceToHotwire = 99

Config.WhitelistVehicles = { -- This list of vehicles won't have hotwire.
    'bmx',
    'cruiser',
    'enduro',
    'fixter',
    'scorcher',
    'tribike',
    'tribike2',
    'tribike3',
}

Config.StealVehiclesPeds = true -- If you enable this, players can target an NPC driver to receive their keys.
Config.StealVehiclesPedsPolice = 50 -- This is the chance for the NPC to call the police after being robbed (1-100).

-- List of weapons you can steal a car with.
Config.StealWeapons = {
    "weapon_pistol",
    "weapon_pistol_mk2",
    "weapon_combatpistol",
    "weapon_appistol",
    "weapon_stungun",
    "weapon_pistol50",
    "weapon_snspistol",
    "weapon_snspistol_mk2",
    "weapon_heavypistol",
    "weapon_vintagepistol",
    "weapon_flaregun",
    "weapon_marksmanpistol",
    "weapon_revolver",
    "weapon_revolver_mk2",
    "weapon_doubleaction",
    "weapon_raypistol",
    "weapon_ceramicpistol",
    "weapon_navyrevolver",
    "weapon_gadgetpistol",
    "weapon_stungun_mp",
    "weapon_pistolxm3",
    "weapon_microsmg",
    "weapon_smg",
    "weapon_smg_mk2",
    "weapon_assaultsmg",
    "weapon_combatpdw",
    "weapon_machinepistol",
    "weapon_minismg",
    "weapon_raycarbine",
    "weapon_tecpistol",
    "weapon_pumpshotgun",
    "weapon_pumpshotgun_mk2",
    "weapon_sawnoffshotgun",
    "weapon_assaultshotgun",
    "weapon_bullpupshotgun",
    "weapon_musket",
    "weapon_heavyshotgun",
    "weapon_dbshotgun",
    "weapon_autoshotgun",
    "weapon_combatshotgun",
    "weapon_assaultrifle",
    "weapon_assaultrifle_mk2",
    "weapon_carbinerifle",
    "weapon_carbinerifle_mk2",
    "weapon_advancedrifle",
    "weapon_specialcarbine",
    "weapon_specialcarbine_mk2",
    "weapon_bullpuprifle",
    "weapon_bullpuprifle_mk2",
    "weapon_compactrifle",
    "weapon_militaryrifle",
    "weapon_heavyrifle",
    "weapon_tacticalrifle",
    "weapon_mg",
    "weapon_combatmg",
    "weapon_combatmg_mk2",
    "weapon_gusenberg",
    "weapon_sniperrifle",
    "weapon_heavysniper",
    "weapon_heavysniper_mk2",
    "weapon_marksmanrifle",
    "weapon_marksmanrifle_mk2",
    "weapon_precisionrifle"
}

--[[
█▀█ █▀█ █░░ █ █▀▀ █▀▀
█▀▀ █▄█ █▄▄ █ █▄▄ ██▄
]]

Config.ReqPolice = false -- Do you want police in your city to enable robberies?
Config.ReqPoliceCount = 1 -- Minimum police to start a robbery.
Config.ReqJobPolice = 'police' -- Police job name.
Config.RefreshPolice = 1000 -- Ammount of time to check por police count again, higher for more performance, don't use below 1000ms.

Config.LockpickItem = 'lockpick' -- Item required to start lockpicking.
Config.LockpickKeepChance = 50 -- Chance of not brekaing the lockpick item and keeping your item (1-100).
Config.LockpickFail = 1
Config.AdvancedLockpickItem = 'caradvancedlockpick' -- Don't need police to lockpick

Config.LockpickAlarm = true -- If you enable this option, the policemen will receive dispatch when the alarm sounds.
Config.StartAlarmChance = 50 -- Chance of the alarm going off, remember this will trigger dispatch to `Config.ReqJobPolice` (1-100).

Config.LockpickWhitelist = { -- These vehicles can't be lockpicked.
    'bmx'
}

-- ██████╗░███████╗██████╗░░██████╗
-- ██╔══██╗██╔════╝██╔══██╗██╔════╝
-- ██████╔╝█████╗░░██║░░██║╚█████╗░
-- ██╔═══╝░██╔══╝░░██║░░██║░╚═══██╗
-- ██║░░░░░███████╗██████╔╝██████╔╝
-- ╚═╝░░░░░╚══════╝╚═════╝░╚═════╝░

-- Ped for copy the keys.
Config.CopyKeysNpcName = 's_m_y_xmech_01'
Config.CopyKeysPedLocation = vec4(-31.402076721191, -1647.4393310547, 29.282875061035, 68.450233459473)

-- Ped for buying the plate item.
Config.PlateNpcName = 'mp_m_waremech_01'
Config.PlateNPCLocation = vec4(-40.4748, -1674.6696, 29.4845, 153.7328)

-- Distance you want the ped to render.
Config.PedRenderDistance = 10.0

-- ███████╗███╗   ███╗ █████╗ ██████╗ ████████╗██████╗ ██╗  ██╗ ██████╗ ███╗   ██╗███████╗
-- ██╔════╝████╗ ████║██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██║  ██║██╔═══██╗████╗  ██║██╔════╝
-- ███████╗██╔████╔██║███████║██████╔╝   ██║   ██████╔╝███████║██║   ██║██╔██╗ ██║█████╗
-- ╚════██║██║╚██╔╝██║██╔══██║██╔══██╗   ██║   ██╔═══╝ ██╔══██║██║   ██║██║╚██╗██║██╔══╝
-- ███████║██║ ╚═╝ ██║██║  ██║██║  ██║   ██║   ██║     ██║  ██║╚██████╔╝██║ ╚████║███████╗
-- ╚══════╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝

Config.Smartphone = false -- If you have qs-smartphone, you can enable this function.
Config.ChargeCommand = 'chargephone' -- Command to load or unload your qs-smartphone.
Config.ChargeStatusCommand = 'chargestatus' -- Command to display or hide the battery percentage while charging.

-- ██████╗░██╗░██████╗██████╗░░█████╗░████████╗░█████╗░██╗░░██╗
-- ██╔══██╗██║██╔════╝██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██║░░██║
-- ██║░░██║██║╚█████╗░██████╔╝███████║░░░██║░░░██║░░╚═╝███████║
-- ██║░░██║██║░╚═══██╗██╔═══╝░██╔══██║░░░██║░░░██║░░██╗██╔══██║
-- ██████╔╝██║██████╔╝██║░░░░░██║░░██║░░░██║░░░╚█████╔╝██║░░██║
-- ╚═════╝░╚═╝╚═════╝░╚═╝░░░░░╚═╝░░╚═╝░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝

Config.Dispatch = "default" -- Options available : "qs", "qs-smartphone", "default"

-- ██████╗░███████╗██████╗░██╗░░░██╗░██████╗░
-- ██╔══██╗██╔════╝██╔══██╗██║░░░██║██╔════╝░
-- ██║░░██║█████╗░░██████╦╝██║░░░██║██║░░██╗░
-- ██║░░██║██╔══╝░░██╔══██╗██║░░░██║██║░░╚██╗
-- ██████╔╝███████╗██████╦╝╚██████╔╝╚██████╔╝
-- ╚═════╝░╚══════╝╚═════╝░░╚═════╝░░╚═════╝░

Config.Debug = false -- If you want to see more about what happens internally in the script use true.
Config.Eventprefix = 'qs-vehiclekeys'
