-- Minigame configuration

-- Choose from the following options for the progress.
-- 'ox_lib' (basic dependency)
-- 'progressbar' https://github.com/quasar-scripts/progressbar
Config.minigameProgress = 'ox_lib'

-- Choose from the following options for the minigame.
-- 'ox_lib' (basic dependency)
-- 't3_lockpick' https://github.com/T3development/t3_lockpick
Config.minigameType = 'ox_lib'

local openingDoor = false
local lockpicking = false
local vehLockpick

function LockpickDoor(isAdvanced)
    local vehicle = GetClosestVehicle()
    if vehicle ~= nil and vehicle ~= 0 then
        vehLockpick = vehicle
        local vehpos = GetEntityCoords(vehLockpick)
        local pos = GetEntityCoords(PlayerPedId())
        if GetDistanceBetweenCoords(pos.x, pos.y, pos.z, vehpos.x, vehpos.y, vehpos.z, true) < 2.0 then
            local lockpickTime = math.random(15000, 30000)
            if isAdvanced then
                lockpickTime = math.ceil(lockpickTime * 0.5)
            end
            LockpickDoorAnim(lockpickTime)
            lockpickMiniGame()
            sHotwiring = true
        end
    end
end

function LockpickDoorAnim(time)
    local ped = PlayerPedId()
    time = time / 1000
    loadAnimDict("veh@break_in@0h@p_m_one@")
    TaskPlayAnim(ped, "veh@break_in@0h@p_m_one@", "low_force_entry_ds", 3.0, 3.0, -1, 16, 0, false, false, false)
    openingDoor = true
    CreateThread(
        function()
            while openingDoor do
                TaskPlayAnim(ped, "veh@break_in@0h@p_m_one@", "low_force_entry_ds", 3.0, 3.0, -1, 16, 0, 0, 0, 0)
                Wait(1000)
                time = time - 1
                if time <= 0 then
                    openingDoor = false
                    StopAnimTask(ped, "veh@break_in@0h@p_m_one@", "low_force_entry_ds", 1.0)
                end
            end
        end
    )
end

function lockpickMiniGame(success)
    local success = false
    local coords = GetEntityCoords(PlayerPedId())
    local lucky = math.random(1, 100)
    if not vehLockpick then
        vehLockpick = GetClosestVehicle()
    end

    if Config.minigameType == 'ox_lib' then
        success = lib.skillCheck({"easy", "easy", "easy", "easy", "easy"})
    end

    if Config.minigameType == 't3_lockpick' then
        local item = Config.LockpickItem
        local difficulty = 3
        local pins = 3
        success = exports["t3_lockpick"]:startLockpick(item, difficulty, pins)
    end

    local coords = GetEntityCoords(PlayerPedId())
    local lucky = math.random(1, 100)

    if not vehLockpick then
        vehLockpick = GetClosestVehicle()
    end

    if success then
        finishLockpick = true

        if lucky >= Config.LockpickFail then
            lockpickLogic(joaat(vehLockpick))

            if Config.LockpickAlarm and lucky > Config.StartAlarmChance then
                startAlarm(vehLockpick)
            end

            if lucky > Config.LockpickKeepChance then
                SendTextMessage(Lang("VEHICLEKEYS_NOTIFICATION_LOCKPICK_BROKEN"), "error")
                TriggerServerEvent(Config.Eventprefix .. ":server:RemoveLockpick", Config.LockpickItem, 1)
            end

            SendTextMessage(Lang("VEHICLEKEYS_NOTIFICATION_LOCKPICK_SUCCESS"), "success")
        else
            startAlarm(vehLockpick)
            SendTextMessage(Lang("VEHICLEKEYS_NOTIFICATION_LOCKPICK_FAIL"), "error")
        end

    else
        startAlarm(vehLockpick)
        SendTextMessage(Lang("VEHICLEKEYS_NOTIFICATION_LOCKPICK_FAIL"), "error")
    end

    TriggerServerEvent(Config.Eventprefix .. ":server:notifyCops", coords)
    StopAnimTask(PlayerPedId(), "veh@break_in@0h@p_m_one@", "low_force_entry_ds", 1.0)

    IsHotwiring = false
    openingDoor = false
    vehLockpick = nil
end

-- Function to handle custom progress bars
function CustomProgBars(time, label)
    if Config.minigameProgress == 'ox_lib' then
        lib.progressCircle({
            duration = time,
            position = "bottom",
            label = label,
            useWhileDead = false,
            canCancel = false,
            disable = {
                car = true
            }
        })
    end

    if Config.minigameProgress == 'progressbar' then
        exports['progressbar']:Progress({
            name = "custom_hotwire",
            duration = time,
            label = label,
            useWhileDead = false,
            canCancel = false,
            controlDisables = {
                disableMovement = true,
                disableCarMovement = true,
                disableMouse = false,
                disableCombat = true,
            },
        }, function(status)
        end)
    end
end
