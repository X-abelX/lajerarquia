-- ██████╗░██╗░██████╗██████╗░░█████╗░████████╗░█████╗░██╗░░██╗
-- ██╔══██╗██║██╔════╝██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██║░░██║
-- ██║░░██║██║╚█████╗░██████╔╝███████║░░░██║░░░██║░░╚═╝███████║
-- ██║░░██║██║░╚═══██╗██╔═══╝░██╔══██║░░░██║░░░██║░░██╗██╔══██║
-- ██████╔╝██║██████╔╝██║░░░░░██║░░██║░░░██║░░░╚█████╔╝██║░░██║
-- ╚═════╝░╚═╝╚═════╝░╚═╝░░░░░╚═╝░░╚═╝░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝

RegisterNetEvent("qs-vehiclekeys:client:notifyCops", function(coords)
    -- Check if the dispatch type is "default" and if the player is a police officer
    if Config.Dispatch == "default" then
        local jobFramework = GetJobFramework()
        if jobFramework ~= nil and jobFramework.name == Config.ReqJobPolice then
            if Config.Debug then
                print("Dispatch event called default")
            end

            -- Set up blip for the notification
            local transG = 300 * 2
            local blip = AddBlipForCoord(coords)
            SetBlipSprite(blip, 161)
            SetBlipColour(blip, 3)
            SetBlipDisplay(blip, 4)
            SetBlipAlpha(blip, transG)
            SetBlipScale(blip, 1.5)
            SetBlipFlashes(blip, true)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString(Lang("VEHICLEKEYS_NOTIFICATION_TITLE"))
            EndTextCommandSetBlipName(blip)

            -- Fade out the blip
            while transG ~= 0 do
                Citizen.Wait(500)
                transG = transG - 1
                SetBlipAlpha(blip, transG)
                if transG == 0 then
                    SetBlipSprite(blip, 2)
                    RemoveBlip(blip)
                    return
                end
            end
        end
    end

    -- Check if the dispatch type is "qs-smartphone"
    if Config.Dispatch == "qs-smartphone" then
        if Config.Debug then
            print("Dispatch event called qs-smartphone")
        end
        TriggerServerEvent("vehiclekeys:server:phoneDispatch", coords, street2)
    end

    -- Check if the dispatch type is "qs"
    if Config.Dispatch == "qs" then
        if Config.Debug then
            print("Dispatch event called qs-dispatch")
        end
        TriggerServerEvent(Config.Eventprefix .. ':server:Dispatch', source)
    end
end)

