RegisterNetEvent(Config.Eventprefix .. ':server:plateupdate', function(oldplate, newplate)
    -- Fetch the vehicle information from the database based on the old plate
    MySQL.Async.fetchAll('SELECT * FROM ' .. vehiclesTable .. ' WHERE ' .. plateTable .. ' = @plate', { ['@plate'] = oldplate },
        function(result)
            -- Debug print for the start of the result processing
            if Config.Debug then
                print('[^3DEBUG^7] Fetching result for plate update...')
            end

            -- Debug print for the pulled data (only printing the keys and their values)
            if Config.Debug then
                print('[^3DEBUG^7] Pulled Data:')
                for key, value in pairs(result[1]) do
                    print('[^3DEBUG^7] ' .. key .. ':', value)
                end
            end

            local vehicle
            if result[1] ~= nil then
                -- Debug print for the start of vehicle information processing
                if Config.Debug then
                    print('[^3DEBUG^7] Processing vehicle information...')
                end

                -- Decode the vehicle information based on the framework
                if Config.Framework == 'esx' then
                    vehicle = json.decode(result[1].vehicle)
                elseif Config.Framework == 'qb' then
                    vehicle = result[1].vehicle
                end

                -- Debug print for the completion of vehicle information processing
                if Config.Debug then
                    print('[^3DEBUG^7] Vehicle information processing complete.')
                end

                -- Debug print for the updated vehicle information (only printing the keys and their values)
                if Config.Debug then
                    print('[^3DEBUG^7] Updated Vehicle Information:')
                    for key, value in pairs(vehicle) do
                        if key == plateTable then
                            print('[^3DEBUG^7] ' .. key .. ': ^1' .. value .. '^7')  -- Highlight the plate in red
                        end
                    end
                end

                -- Debug print for the plate change
                if Config.Debug then
                    print('[^3DEBUG^7] Plate changed to new plate: ^1[' .. newplate .. ']^7, old plate: ^1[' .. oldplate .. ']^7')
                end

                -- Update the database with the new plate and vehicle information
                MySQL.Async.execute('UPDATE ' .. vehiclesTable .. ' SET ' .. plateTable .. ' = @newplate, vehicle = @vehicle WHERE ' .. plateTable .. ' = @oldplate', { ['@newplate'] = newplate, ['@oldplate'] = oldplate, ['@vehicle'] = json.encode(vehicle) })

                -- Check if the qs-advancedgarages resource is started and update the vehicle plate
                if GetResourceState('qs-advancedgarages') == 'started' then
                    exports['qs-advancedgarages']:updateVehiclePlate(oldplate, newplate)
                end
            else
                -- Debug print if result is nil
                if Config.Debug then
                    print('[^3DEBUG^7] Result is nil for plate update. No action taken.')
                end
            end
        end)
end)
