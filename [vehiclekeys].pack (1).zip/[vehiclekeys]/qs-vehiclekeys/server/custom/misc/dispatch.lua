RegisterNetEvent(Config.Eventprefix..':server:phoneDispatch', function(coords, street2)
    local alertData = {
        title = Lang("VEHICLEKEYS_NOTIFICATION_TITLE"),
        coords = {x = coords.x, y = coords.y, z = coords.z},
        description = Lang("VEHICLEKEYS_NOTIFICATION_POLICE_DISPATCH").." "..street2
    }
    TriggerClientEvent("qs-smartphone:client:addPoliceAlert", -1, alertData)
end)

RegisterNetEvent(Config.Eventprefix..':server:Dispatch', function(source)
    local PlayerID = source

    exports['qs-dispatch']:GetPlayerInfo(PlayerID, function(playerData)
        if (not playerData) then
            ErrorPrint("Error getting player data")
            return
        end

        TriggerEvent('qs-dispatch:server:CreateDispatchCall', {
            job = { Config.JobPolice },
            callLocation = playerData.coords,
            callCode = { code = "10-42", snippet = "Vehicle Theft" },
            message = 'A ' .. playerData.sex .. ' has solten a vehicle near ' .. playerData.street_1 .. '.',
            flashes = false,
            image = nil,
            blip = {
                sprite = 490,
                scale = 1.5,
                colour = 1,
                flashes = false,
                text = "Vehicle Theft",
                time = (3 * 60 * 1000),
            },
            otherData = {
                {
                    text = 'Vehicle Theft',
                    icon = 'fas fa-car-side',
                }
            }
        })
    end)
end)
