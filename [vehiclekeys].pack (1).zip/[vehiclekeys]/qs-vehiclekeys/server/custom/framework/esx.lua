--[[
    Hi dear customer or developer, here you can fully configure your server's
    framework or you could even duplicate this file to create your own framework.
    If you do not have much experience, we recommend you download the base version
    of the framework that you use in its latest version and it will work perfectly.
]]

if Config.Framework ~= 'esx' then
    return
end

local version = GetResourceMetadata('es_extended', 'version', 0)

if version == '1.1.0' or version == '1.2.0' or version == 'legacy' then
    ESX = nil
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
else
    ESX = exports['es_extended']:getSharedObject()
end

identifierTypes = 'owner'
vehiclesTable = 'owned_vehicles'
plateTable = 'plate'


function RegisterServerCallback(name, cb)
    ESX.RegisterServerCallback(name, cb)
end

function GetPlayerFromIdFramework(player)
    local Player = ESX.GetPlayerFromId(player)
    return Player
end

function GetPlayerIdentifier(player)
    return ESX.GetPlayerFromId(player).identifier
end

function GetPlayerJob(player)
    return player.getJob().name
end

function GetPlayerDuty(player)
    return true
end

function GetPlayers()
    return ESX.GetPlayers()
end

function GetMoney(player)
    return player.getMoney()
end

function RemoveMoney(player, mount)
    return player.removeMoney(mount)
end

function GetAccountMoney(player, account)
    return player.getAccount(account).money
end

function RemovAccountMoney(player, account, mount)
    return player.removeAccountMoney(account, mount)
end

function RegisterUsableItem(name, cb)
    ESX.RegisterUsableItem(name, cb)
end

-- Server-side code (Lua)
RegisterServerEvent('CheckPlayerItem')
AddEventHandler('CheckPlayerItem', function(item)
    local source = source
    -- Replace this with your actual logic to check if the player has the item
    local hasItem = CheckIfPlayerHasItem(source, item)
    TriggerClientEvent('CheckPlayerItemResult', source, hasItem)
end)


function GetItem(player, item)
    return player.getInventoryItem(item)
end

function GetItemCount(player, item)
    return player.getInventoryItem(item).count
end

function AddItem(player, item, metadata)
    player.addInventoryItem(item, 1, metadata)
end

function RemoveItem(player, item)
    player.removeInventoryItem(item, 1, metadata)
end

function SetInventoryItem(player)
    return true
end

function AddItemMetadata(player, item, slot, metadata)
    if not player then return end
    if Config.InventoryScript == 'qs' then
        exports['qs-inventory']:AddItem(player.source, item, 1, nil, metadata)
    elseif Config.InventoryScript == 'qb' then
        player.Functions.AddItem(item, 1, false, metadata)
    elseif Config.InventoryScript == 'ox' then
        ox_inventory:AddItem(player.source, item, 1, metadata)
    elseif Config.InventoryScript == 'origen' then
        exports["origen_inventory"]:AddItem(player.source, item, 1, nil, metadata)
    elseif Config.InventoryScript == 'core_inventory' then
        local inv = 'content-' .. player.identifier:gsub(':', '')
        exports['core_inventory']:addItem(inv, item, 1, metadata)
    elseif Config.InventoryScript == 'codem' then
        exports["codem-inventory"]:AddItem(player.source, item, 1, nil, metadata)
    else
        error('Inventory bad configured')
    end
end

function GetMetadata(player, item, slot, metadata)
    if not player then return end
    if Config.InventoryScript == 'qs' then
        return exports['qs-inventory']:GetInventory(player.source)
    elseif Config.InventoryScript == 'qb' then
        return player.PlayerData.items
    elseif Config.InventoryScript == 'origen' then
        return exports['origen_inventory']:GetInventory(player.source)
    elseif Config.InventoryScript == 'ox' then
        return ox_inventory:GetInventoryItems(player.source)
    elseif Config.InventoryScript == 'core_inventory' then
        local inv = 'content-' .. player.identifier:gsub(':', '')
        return exports['core_inventory']:getInventory(inv)
    elseif Config.InventoryScript == 'codem' then
        return exports["codem-inventory"]:GetUserInventory(player.source)
    else
        error('Inventory bad configured')
    end
end

function RemoveItemMetadata(player, item, slot, metadata)
    if not player then return end
    if Config.InventoryScript == 'qs' then
        exports['qs-inventory']:RemoveItem(player.source, item, 1, slot, metadata)
    elseif Config.InventoryScript == 'qb' then
        player.Functions.RemoveItem(item, 1, false)
    elseif Config.InventoryScript == 'ox' then
        ox_inventory:RemoveItem(player.source, item, 1, metadata, slot)
    elseif Config.InventoryScript == 'origen' then
        exports["origen_inventory"]:RemoveItem(player.source, item, 1, slot)
    elseif Config.InventoryScript == 'core_inventory' then
        local inv = 'content-' .. player.identifier:gsub(':', '')
        exports['core_inventory']:removeItemExact(inv, metadata.id, 1)
    elseif Config.InventoryScript == 'codem' then
        exports["codem-inventory"]:RemoveItem(player.source, item, 1, slot)
    else
        error('Inventory bad configured')
    end
end
