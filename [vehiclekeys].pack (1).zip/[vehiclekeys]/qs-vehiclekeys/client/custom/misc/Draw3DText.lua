-- Function to draw 3D text based on the chosen method
local isTextVisible = true

-- Function to draw 3D text based on the chosen method
function Draw3DText(x, y, z, text)
    local playerPed = GetPlayerPed(-1)

    if IsPedInAnyVehicle(playerPed, false) then
        if isTextVisible then
            if Config.ReplaceDraw3D then
                if Config.TextUI == 'Draw3DText' then
                    Config.ReplaceDraw3D = false
                elseif Config.TextUI == 'HelpNotification' then
                    TextShow(text)
                elseif Config.TextUI == 'ox_lib' then
                    TextShow(text) -- Use the ox_lib function
                elseif Config.TextUI == 'esx_textui' then
                    TextShow(text) -- Use the esx_textui function
                elseif Config.TextUI == 'qb' then
                    TextShow(text) -- Use the qb function
                elseif Config.TextUI == 'okokTextUI' then
                    print("DEBUG: okokTextUI is currently bugged and will not display correctly.")
                end
            else
                DrawText3D(x, y, z, text)
            end
            isTextVisible = false
        end
    else
        TextClose()
        isTextVisible = true
    end
end

