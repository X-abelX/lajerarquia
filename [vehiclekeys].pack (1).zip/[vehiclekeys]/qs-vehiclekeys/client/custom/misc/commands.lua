RegisterCommand('engine', function()
    if inHotwire then return end
    TriggerEvent(Config.Eventprefix..":client:ToggleEngine")
end)

if Config.HotKeys then
    RegisterKeyMapping('engine', 'Toggle engine', 'mouse_wheel', Config.Controls['EngineControl'])
end

RegisterCommand('usekey', function()
    UseCommandKey()
end)

if Config.HotKeys then
    RegisterKeyMapping('usekey', 'Open/Close vehicle', 'keyboard', Config.Controls['UseKey'])
end
