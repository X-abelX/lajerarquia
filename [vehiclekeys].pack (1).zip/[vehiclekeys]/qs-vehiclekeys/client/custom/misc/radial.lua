--[[
██████╗░░█████╗░██████╗░██╗░█████╗░██╗░░░░░  ███╗░░░███╗███████╗███╗░░██╗██╗░░░██╗
██╔══██╗██╔══██╗██╔══██╗██║██╔══██╗██║░░░░░  ████╗░████║██╔════╝████╗░██║██║░░░██║
██████╔╝███████║██║░░██║██║███████║██║░░░░░  ██╔████╔██║█████╗░░██╔██╗██║██║░░░██║
██╔══██╗██╔══██║██║░░██║██║██╔══██║██║░░░░░  ██║╚██╔╝██║██╔══╝░░██║╚████║██║░░░██║
██║░░██║██║░░██║██████╔╝██║██║░░██║███████╗  ██║░╚═╝░██║███████╗██║░╚███║╚██████╔╝
╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░╚═╝╚═╝░░╚═╝╚══════╝  ╚═╝░░░░░╚═╝╚══════╝╚═╝░░╚══╝░╚═════╝░
]]--

-- Function to get the closest vehicle and its distance
function GetClosestVehicle()
	local playerCoords = GetEntityCoords(PlayerPedId())
	local vehicles = GetGamePool("CVehicle")

	local closestVehicle, closestDistance

	for _, vehicle in ipairs(vehicles) do
		local distance = #(playerCoords - GetEntityCoords(vehicle))^2

		if not closestDistance or distance < closestDistance then
			closestVehicle = vehicle
			closestDistance = math.sqrt(distance)
		end
	end

	return closestVehicle, closestDistance
end

-- Check if Radial is enabled in the configuration
if not Config.Radial then return end

-- Check if Radial is set to 'ox' in the configuration
if Config.Radial == 'ox' then

Citizen.CreateThread(function()
    local radialItemAdded = false  -- Flag to track if radial item is added

    while true do
        Wait(1000)  -- Adjust the interval if needed, for example, 1000 milliseconds (1 second)

        local maxDistance = 4.0  -- Set the maximum distance here

        local vehicle, distance = GetClosestVehicle()

        if vehicle and distance < maxDistance then
            if not radialItemAdded then
                lib.addRadialItem({
                    {
                        id = 'carkeys',
                        label = Lang('VEHICLEKEYS_RADIAL_VEHICLEKEYS_LABEL'),
                        icon = "key",
                        onSelect = function()
                            ExecuteCommand('usekey')
                        end
                    }
                })
                radialItemAdded = true  -- Set the flag to true since the item is added
            end
        else
            if radialItemAdded then
                lib.removeRadialItem('carkeys')
                radialItemAdded = false  -- Set the flag to false since the item is removed
            end
        end
    end
end)

--[[
█▀▀ ▄▀█ █▀█   █▀▄ █▀█ █▀█ █▀█ █▀
█▄▄ █▀█ █▀▄   █▄▀ █▄█ █▄█ █▀▄ ▄█
]]--

lib.registerRadial({
    id = 'car_doors',
    items = {
        {
            label = Lang('VEHICLEKEYS_RADIAL_REARRIGHT_LABEL'),
            icon = 'car-side',
            onSelect = function()
                doorToggle(3)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_TRUNK_LABEL'),
            icon = 'car-rear',
            onSelect = function()
                doorToggle(5)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_PASSENGER_LABEL'),
            icon = 'car-side',
            onSelect = function()
                doorToggle(1)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_DRIVER_LABEL'),
            icon = 'car-side',
            onSelect = function()
                doorToggle(0)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_HOOD_LABEL'),
            icon = 'car',
            onSelect = function()
                doorToggle(4)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_REARLEFT_LABEL'),
            icon = 'car-side',
            onSelect = function()
                doorToggle(2)
            end
        },
    }
})

--[[
█▀▀ ▄▀█ █▀█   █░█░█ █ █▄░█ █▀▄ █▀█ █░█░█ █▀
█▄▄ █▀█ █▀▄   ▀▄▀▄▀ █ █░▀█ █▄▀ █▄█ ▀▄▀▄▀ ▄█
]]--

lib.registerRadial({
    id = 'car_windows',
    items = {
        {
            label = Lang('VEHICLEKEYS_RADIAL_REARRIGHT_LABEL'),
            icon = 'caret-right',
            onSelect = function()
                windowToggle(2, 3)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_PASSENGER_LABEL'),
            icon = 'caret-up',
            onSelect = function()
                windowToggle(1, 1)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_DRIVER_LABEL'),
            icon = 'caret-up',
            onSelect = function()
                windowToggle(0, 0)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_REARLEFT_LABEL'),
            icon = 'caret-left',
            onSelect = function()
                windowToggle(3, 2)
            end
        },
    }
})

--[[
█▀▀ ▄▀█ █▀█   █▀ █▀▀ ▄▀█ ▀█▀ █▀
█▄▄ █▀█ █▀▄   ▄█ ██▄ █▀█ ░█░ ▄█
]]--

lib.registerRadial({
    id = 'car_seats',
    items = {
        {
            label = Lang('VEHICLEKEYS_RADIAL_REARRIGHT_LABEL'),
            icon = 'caret-right',
            onSelect = function()
                changeSeat(2)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_PASSENGER_LABEL'),
            icon = 'caret-up',
            onSelect = function()
                changeSeat(0)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_DRIVER_LABEL'),
            icon = 'caret-up',
            onSelect = function()
                changeSeat(-1)
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_REARLEFT_LABEL'),
            icon = 'caret-left',
            onSelect = function()
                changeSeat(1)
            end
        },
    }
})

--[[
█░█ █▀▀ █░█ █ █▀▀ █░░ █▀▀   █▀▄▀█ █▀▀ █▄░█ █░█
▀▄▀ ██▄ █▀█ █ █▄▄ █▄▄ ██▄   █░▀░█ ██▄ █░▀█ █▄█
]]--

lib.registerRadial({
    id = 'vehicle_menu',
    items = {
        {
            label = Lang('VEHICLEKEYS_RADIAL_VEHICLEENGINE_LABEL'),
            icon = 'power-off',
            onSelect = function()
                ExecuteCommand('engine')
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_VEHICLEDOORS_LABEL'),
            icon = 'door-closed',
            menu = 'car_doors'
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_VEHICLEWINDOWS_LABEL'),
            icon = 'window-maximize',
            menu = 'car_windows'
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_VEHICLECHAIRS_LABEL'),
            icon = 'chair',
            menu = 'car_seats'
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_VEHICLESEATBELT_LABEL'),
            icon = "user-lock",
            onSelect = function()
            ExecuteCommand('/toggleseatbelt')
            end
        },
        {
            label = Lang('VEHICLEKEYS_RADIAL_VEHICLEKEYS_LABEL'),
            icon = "key",
            onSelect = function()
                ExecuteCommand('usekey')
            end
        },
        }
})

--[[
█░█ █▀▀ █░█ █ █▀▀ █░░ █▀▀   █▀▀ █░█ █▀▀ █▀▀ █▄▀
▀▄▀ ██▄ █▀█ █ █▄▄ █▄▄ ██▄   █▄▄ █▀█ ██▄ █▄▄ █░█
]]--

lib.onCache('vehicle', function(value)
    if value then
        lib.addRadialItem({
            {
                id = 'vehicle',
                label = Lang('VEHICLEKEYS_RADIAL_VEHICLE_LABEL'),
                icon = 'car',
                menu = 'vehicle_menu'
            }
        })
      lib.removeRadialItem('carkeys')
    else
        lib.removeRadialItem('vehicle')
        lib.addRadialItem({
          {
            id = 'carkeys',
            label = Lang('VEHICLEKEYS_RADIAL_VEHICLEKEYS_LABEL'),
            icon = "key",
            onSelect = function()
                ExecuteCommand('usekey')
            end
          }
        })
    end
end)

end

if Config.Radial == 'qb' then

--[[
█░█ █▀▀ █░█ █ █▀▀ █░░ █▀▀   █▀▀ █░█ █▀▀ █▀▀ █▄▀
▀▄▀ ██▄ █▀█ █ █▄▄ █▄▄ ██▄   █▄▄ █▀█ ██▄ █▄▄ █░█
]]--

if IsPedInAnyVehicle(GetPlayerPed(-1)) then
            menuItems = {}
            table.insert(menuItems,
                {
                    id = "vehicle",
                    title = "Vehicle",
                    icon = "car",
                    items = {
                        {
                            id = "power-off",
                            title = Lang("VEHICLEKEYS_RADIAL_VEHICLEENGINE_LABEL"),
                            icon = "power-off",
                            Func = function()
                                ExecuteCommand("engine")
                            end,
                            shouldClose = true
                        },
                        {
                            id = "car_doors",
                            title = Lang("VEHICLEKEYS_RADIAL_VEHICLEDOORS_LABEL"),
                            icon = "door-closed",
                            items = {
                                {
                                    id = "doorrearright",
                                    title = Lang("VEHICLEKEYS_RADIAL_REARRIGHT_LABEL"),
                                    icon = "caret-right",
                                    Func = function()
                                        windowToggle(2, 3)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "doorpassenger",
                                    title = Lang("VEHICLEKEYS_RADIAL_PASSENGER_LABEL"),
                                    icon = "caret-up",
                                    Func = function()
                                        windowToggle(1, 1)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "doordriver",
                                    title = Lang("VEHICLEKEYS_RADIAL_DRIVER_LABEL"),
                                    icon = "caret-up",
                                    Func = function()
                                        windowToggle(0, 0)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "doorrearleft",
                                    title = Lang("VEHICLEKEYS_RADIAL_REARLEFT_LABEL"),
                                    icon = "caret-left",
                                    Func = function()
                                        windowToggle(3, 2)
                                    end,
                                    shouldClose = true
                                }
                            }
                        },
                        {
                            id = "car_seats",
                            title = Lang("VEHICLEKEYS_RADIAL_VEHICLECHAIRS_LABEL"),
                            icon = "chair",
                            items = {
                                {
                                    id = "seatrearright",
                                    title = Lang("VEHICLEKEYS_RADIAL_REARRIGHT_LABEL"),
                                    icon = "caret-right",
                                    Func = function()
                                        changeSeat(2)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "seatpassenger",
                                    title = Lang("VEHICLEKEYS_RADIAL_PASSENGER_LABEL"),
                                    icon = "caret-up",
                                    Func = function()
                                        changeSeat(0)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "doordriver",
                                    title = Lang("VEHICLEKEYS_RADIAL_DRIVER_LABEL"),
                                    icon = "caret-up",
                                    Func = function()
                                        changeSeat(-1)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "seatrearleft",
                                    title = Lang("VEHICLEKEYS_RADIAL_REARLEFT_LABEL"),
                                    icon = "caret-left",
                                    Func = function()
                                        changeSeat(1)
                                    end,
                                    shouldClose = true
                                }
                            }
                        },
                        {
                            id = "car_windows",
                            title = Lang("VEHICLEKEYS_RADIAL_VEHICLEWINDOWS_LABEL"),
                            icon = "window-maximize",
                            items = {
                                {
                                    id = "doorrearright",
                                    title = Lang("VEHICLEKEYS_RADIAL_REARRIGHT_LABEL"),
                                    icon = "car-side",
                                    Func = function()
                                        doorToggle(3)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "doortrunk",
                                    title = Lang("VEHICLEKEYS_RADIAL_TRUNK_LABEL"),
                                    icon = "car-rear",
                                    Func = function()
                                        doorToggle(5)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "doorpassenger",
                                    title = Lang("VEHICLEKEYS_RADIAL_PASSENGER_LABEL"),
                                    icon = "car-side",
                                    Func = function()
                                        doorToggle(1)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "doorhood",
                                    title = Lang("VEHICLEKEYS_RADIAL_HOOD_LABEL"),
                                    icon = "car",
                                    Func = function()
                                        doorToggle(4)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "doordriver",
                                    title = Lang("VEHICLEKEYS_RADIAL_DRIVER_LABEL"),
                                    icon = "car-side",
                                    Func = function()
                                        doorToggle(0)
                                    end,
                                    shouldClose = true
                                },
                                {
                                    id = "doorrearleft",
                                    title = Lang("VEHICLEKEYS_RADIAL_REARLEFT_LABEL"),
                                    icon = "car-side",
                                    Func = function()
                                        doorToggle(2)
                                    end,
                                    shouldClose = true
                                }
                            }
                        },
                        {
                            id = "engine",
                            title = Lang("VEHICLEKEYS_RADIAL_VEHICLEENGINE_LABEL"),
                            icon = "power-off",
                            Func = function()
                                ExecuteCommand("engine")
                            end,
                            shouldClose = true
                        },
                        {
                            id = "keys",
                            label = Lang("VEHICLEKEYS_RADIAL_VEHICLEKEYS_LABEL"),
                            icon = "key",
                            Func = function()
                                ExecuteCommand("usekey")
                            end,
                            shouldClose = true
                        },
                        {
                            id = "seatbelt",
                            label = Lang("VEHICLEKEYS_RADIAL_VEHICLESEATBELT_LABEL"),
                            icon = "user-lock",
                            Func = function()
                                ExecuteCommand("engine")
                            end,
                            shouldClose = true
                        }
                    }
                }
            )
            for _, item in ipairs(menuItems) do
                item.id = exports[qbcoreRadial]:AddOption(item)
            end
        else
            RemoveRadialOptions()
        end


function RemoveRadialOptions()
    for _, item in ipairs(menuItems) do
        exports[qbcoreRadial]:RemoveOption(item.id)
    end
    menuItems = {}
end

RegisterNetEvent('qb-radialmenu:client:onRadialmenuOpen', function()
    AddRadialOption()
end)

AddEventHandler('onResourceStop', function(resourceName)
    if (resourceName == 'qs-vehiclekeys') then
        RemoveRadialOptions()
    end
end)

end

--[[
█▀▀ █░█ █▄░█ █▀▀ ▀█▀ █ █▀█ █▄░█   █▀▄ █▀█ █▀█ █▀█ ▀█▀ █▀█ █▀▀ █▀▀ █░░ █▀▀
█▀░ █▄█ █░▀█ █▄▄ ░█░ █ █▄█ █░▀█   █▄▀ █▄█ █▄█ █▀▄ ░█░ █▄█ █▄█ █▄█ █▄▄ ██▄
]]--

function doorToggle(door)
    if GetVehicleDoorAngleRatio(cache.vehicle, door) > 0.0 then
        SetVehicleDoorShut(cache.vehicle, door, false, false)
    else
        SetVehicleDoorOpen(cache.vehicle, door, false, false)
    end
end

--[[
█▀▀ █░█ █▄░█ █▀▀ ▀█▀ █ █▀█ █▄░█   █▀▀ █░█ ▄▀█ █▄░█ █▀▀ █▀▀ █▀ █▀▀ ▄▀█ ▀█▀
█▀░ █▄█ █░▀█ █▄▄ ░█░ █ █▄█ █░▀█   █▄▄ █▀█ █▀█ █░▀█ █▄█ ██▄ ▄█ ██▄ █▀█ ░█░
]]--

function changeSeat(seat) -- Check seat is empty and move to it
    if (IsVehicleSeatFree(cache.vehicle, seat)) then
        SetPedIntoVehicle(cache.ped, cache.vehicle, seat)
    end
end

--[[
█▀▀ █░█ █▄░█ █▀▀ ▀█▀ █ █▀█ █▄░█   █░█░█ █ █▄░█ █▀▄ █▀█ █░█░█ ▀█▀ █▀█ █▀▀ █▀▀ █░░ █▀▀
█▀░ █▄█ █░▀█ █▄▄ ░█░ █ █▄█ █░▀█   ▀▄▀▄▀ █ █░▀█ █▄▀ █▄█ ▀▄▀▄▀ ░█░ █▄█ █▄█ █▄█ █▄▄ ██▄
]]--

local windows = { true, true, true, true }

function windowToggle(window, door) -- Check window is open/closed and do opposite
    if GetIsDoorValid(cache.vehicle, door) and windows[window + 1] then
        RollDownWindow(cache.vehicle, window)
        windows[window + 1] = false
    else
        RollUpWindow(cache.vehicle, window)
        windows[window + 1] = true
    end
end
