-- Check if TextUI is enabled in the configuration
if Config.TextUI ~= "ox_lib" then
    return
end

-- Function to display text using TextUI
function TextShow(msg)
    -- Check if TextUI is already open
    if lib.isTextUIOpen() then
        return
    else
        -- Set the custom icon if available, otherwise use an empty string
        local icon = Config.CustomIcon or ''

        -- Check if custom design for TextUI is enabled in the configuration
        if Config.CustomDesignTextUI then
            -- Display TextUI with custom design
            lib.showTextUI(msg, {
                icon = icon,
                style = {
                    borderRadius = 0,
                    backgroundColor = '#141517',
                    color = '#d6d6d6'
                }
            })
        else
            -- Display TextUI with default design
            lib.showTextUI(msg, { icon = icon })
        end
    end
end

-- Function to close the TextUI
function TextClose(textToClose)
    -- Check if TextUI is open, then retrieve its status and current text
    local bool, text = lib.isTextUIOpen()

    -- Check if TextUI is open
    if bool then
        -- Check if the current text matches the specified text to close
        if text == textToClose then
            -- If matched, hide the TextUI
            lib.hideTextUI()
        end
    end
end
