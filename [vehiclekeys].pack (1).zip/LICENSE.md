SOFTWARE PRODUCT LICENSE

The SOFTWARE PRODUCT is protected by copyright laws and treaties
international copyright law, as well as other intellectual property laws and treaties.
The SOFTWARE PRODUCT is licensed and may not be resold.

GRANT OF LICENSE. This EULA gives you the following rights:

Application Software. You may install and use one copy of the SOFTWARE PRODUCT or
any previous version for the same operating system on a single computer or PC. The main user
of the equipment or PC on which the SOFTWARE PRODUCT was installed may make a second copy for your
exclusive use on a computer, laptop PC or virtual machine.

Storage/Network Usage. You may also store or install a copy of the PRODUCT
SOFTWARE on a storage device, such as a network server, that is used only for
install or run the SOFTWARE PRODUCT on your other computers or PCs within an internal network; without
However, you will need to acquire and dedicate a license for each separate PC or computer on whose device you
storage install or run the SOFTWARE PRODUCT. You may not share or use
simultaneously on different PCs a license for the SOFTWARE PRODUCT.

You are also authorized to make the number of secondary copies for use on the equipment or PCs
laptops specified above.

Rent. You may not rent, lease or lend the SOFTWARE PRODUCT.

Support services. Quasar Store may provide support services
relating to the SOFTWARE PRODUCT. The use of the Services of
support is governed by the provisions and programs of Quasar Store that are described in the
user manual, in the "online" documentation and/or in other materials provided by Quasar Store.
Any supplemental software code provided as part of the Services
support shall be considered part of the SOFTWARE PRODUCT and shall be subject to the terms and conditions
of this EULA. With respect to the technical information that you provide to Quasar Store as
part of the Support Services, Quasar Store may use that information for commercial purposes,
even for product support and development. will not use that information in a way that
identify you personally.

Software Transfer. All rights granted by this EULA may only be
transfer permanently on the condition that you retain no copies, that you transfer the
entire SOFTWARE PRODUCT (including all component parts, media and
printed materials, any updates, this EULA and if applicable, the Certificate of
Authenticity), and that the recipient agrees to the terms of this EULA.