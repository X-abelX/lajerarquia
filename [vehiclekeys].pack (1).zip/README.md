DOCUMENTATION AND DETAILS OF THE SOFTWARE PRODUCT

The SOFTWARE PRODUCT is protected by copyright laws and treaties
international copyright law, as well as other intellectual property laws and treaties.
The SOFTWARE PRODUCT is licensed and may not be resold.

Read all copyright information at LICENSE.md.

This SOFTWARE PRODUCT includes extensive documentation provided by the Quasar Store 
at the https://docs.quasar-store.com/ link. there you will have all the installation 
guide and basic use of the resource, even so we have a support dedicated exclusively 
to help you with the SOFTWARE PRODUCT directly from https://discord.gg/quasarstore.